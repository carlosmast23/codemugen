Takuma Sakazaki(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<.DEF Overview>=====

Takuma-KOF98.def -> Takuma Sakazaki
MrKarate.def -> Mr.Karate


=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


-- Throw
Ohsoto Gari - F, y

Ippon Zeoi - F, b


-- Command Moves
Oni Guruma - F, x

Kawara Wari - F, a


-- Super Moves
Ko'ou Ken - D, DF, F, x or y

Hien Shippu Kyaku - (charge)DB, F, a or b

Zanretsu Ken - F, B, F, x or y

Shouran Kyaku - F, DF, D, DB, B, a or b

Mouko Burai Gan - D, DB, B, x or y

Haoh Sikou Ken - F, B, DB, D, DF, F, x or y


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Ryuko Ranbu - D, DF, F, DF, D, DB, B, x or y

Shin Kishin Geki - D, DF, F, D, DF, F, x or y


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Ryuko Ranbu - D, DF, F, DF, D, DB, B, x or y

Shin Kishin Geki - D, DF, F, D, DF, F, x or y


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
Cirio
fxm508
JFCT555
Kong
Ohgaki
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
