Name: Giano Vagrante
Age : 78 
Height : 192 cm
Weight : 108 Kg
Nationality : Albanian
Combat Stile: ghost Style
What she likes: smoke
What He dislikes : ghost
He looks like : a KOF character
 

----------------------------------------------------------
-throws & grabs:

fwd + y

fwd + b



-come here:

f+x


-super charge:(only vs ubu,ella,kuando,giano)

D,DF,F c

-special charge:

D,DF,F c

-super guard: (timing)

y or b

------------------------------------------------------
SPECIALS:


-demasiado Punch low:
D, DF, F, x 

-demasiado Punch high:
D, DF, F, y 



-giostradecodos
F, D, DF, x 

F, D, DF, y


  
-katarro:
D, DB, B, x 

-urlodellodio:
D, DB, B,  y




-amarillodentro:(unguardable)
F, B, DB, D, DF, F,   a

-amarillosotto:(unguardable)
F, B, DB, D, DF, F,   b

 


-tagliolaria: 
D, DB, B, a 

D, DB, B,  b




-chiodocrudo & pirsing:
D, DF, F, a

-palmobravo & uppercut:
D, DF, F, b 




-special jump: 
UP (during: tagliolaria - amarillosotto - palmobravo)




-arroto: (during special jump)
D, DB, B, a 

D, DB, B,  b


-ovo crush: (during special jump)
D, DB, B, x 

D, DB, B,  y



-----------------------------------------------------------


SUPER(level 1 gauge):

-finestra sull'odio:
D, DF, F, D, DF, F, x or y


-governopazzo:
D, DF, F, DF, D, DB, B, x or y


-carambola: (when close)
D, DB, B, D, DB, B, x or y



----------------------------------------------------------
SUPER(level 2 gauge):

-mangia il mio cibo:
D, DF, F, D, DF, F, x+y


-imperosadico:
D, DF, F, DF, D, DB, B, x+y


filotto reale: (when close)
D, DB, B, D, DB, B, x+y




--------------------------------------------------------

-COMBOS: *

Y \\ F, x \\ D, DF, F, b \\ D, DF, F, x \\ D, DF, F, a \\ D, DF, F, y \\ F, D, DF, y 


D, D, D, x \\ D, DF, F, b \\ D, DF, F, x \\ D, DB, B, a \\ UP \\ D, DB, B, a \\ D, DB, B, x


Y \\ F, x \\ D, DF, F, x \\ D, DF, F, b \\ D, DB, B, D, DB, B, x+y


D, DB, B,  y \\ D, DF, F, x \\ D, DB, B, a \\ F, D, DF, y


D, D, D, x \\ D, DF, F, x \\ D, DF, F, b \\ UP \\ c


D, D, D, y \\ UP \\ D, DB, B, a \\ D, DB, B, x


Y \\ D, DF, F, x \\ D, DF, F, b \\ D, DB, B, b


c \\ D, DF, F, a \\ D, DB, B, a \ F, D, DF, y


D, DB, B,  b \\ D, DF, F, y \\ F, D, DF, y


D, DF, F, b \\ D, DB, B, a \\ F, D, DF, y


(on air) a \\ y \\ c


and others...

* during giano's combos some moves change skills ( D, DF, F, b  -  D, DF, F, x)

--------------------------------------------------------



DISCLAIMER: 
This character is for WIN-M.U.G.E.N. use only. 
I will not be held responsable for any damage done to your Computer, your parents, your car...
...or your life. (muahahaha!!!)

-------------------------------------------------------
INFO ABOUT THIS CHARACTER:
GIANO is an original character maded by AIDUZZI 

CREDITS:
thanks to Elecbyte for making MUGEN
thanks to Antonio Navarra for hosting our character on his site (P.S. Antonio Navarra IS NOT AIDUZZI!!!)
thanks to Reu for giving me the honour to collaborate with him on the new version of EvilRyu!
thanks to Thundershock that is one of my best fan and contributor ;-)
thanks to all mugenizers that help me to love MUGEN!


Sorry for my bad english...
For contact and suggestions visit the site: www.thephotonfalls.com














