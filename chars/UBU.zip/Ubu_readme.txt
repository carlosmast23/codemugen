-------------------------
 UBU by Aiduzzi (ver 3.5)
-------------------------

First, some info about Ubu:

Name: Ubu Vagrante
Age : 69
Height : 187 cm
Weight : 95 Kg
Nationality : Albanian
Combat Stile: Barocco Stile
What He likes: the "gessato"
What He dislikes : short men
He loves; his own son...Palonzo Vagrante
He hates : short men
He looks like : a KOF 2001 character

----------------------------------------------------------------
ubu ver3.5
a lot of new stuff!  :)
special charge vs giano
new sprites
new fwd + x
cns fix 
air fix
cmd fix
many many many fix

-----------------------------------------------------------------
COMMANDS:
(based on a microsoft "sidewinder" joypad)

-throws & grabs: 

fwd + y

fwd + b

------------------------------------------------------------------

-dir+button:

fwd + x

b (when close hits knowdown enemy)

c (can stop p2 projectiles)

bwd + a (durimg jump)


-super charge:(only vs ubu,ella,kuando,giano)

D,DF,F c

-special charge:

D,DF,F c

-------------------------------------------------------------------

-SPECIAL MOVES

pachbell cannon: qcf + x or (y unguardable)

burning meriggio: dp + x or y

vagrante reversal: hcb + x

proj reversal : hcb + y (rev. projectiles)

presa speciale: hcf + x or y (when close)

stop the piccion: rdp +x or y

calcio oberon: qcf + a or b

(calcio oberon): qcf + b (close to the enemy)

this is the head: hcf + a or b

burning ground: qcb + a (became a throw when close)

burning horizon: qcb +  b

calcio scevro: qcb + a or b (during jump)


---------------------------------------------------------------------

-DM MOVES (1 level gauge)

this is the hand: 2qcf + x or y

cornoventraglia: qcf, hcb + x or y (reversal attack)

kill the piccion: 2qcb + x or y (during "stop the piccion")

rainonme: 2qcf + x or y (during jump)

enought: 2qcf + a or b or 2qcb + a or b

----------------------------------------------------------------------

-SDM MOVES (2 level gauge)

the end in my hands: 2qcf + x+y

sonatine: qcf, hcb + x+y (reversal attack)

tondeki wondeki: 2qcb + x+y (during "stop the piccion")

rainonmemax: 2qcf + x+y (during jump)

enoughtmax: 2qcf + a+b or 2qcb + a+b

-----------------------------------------------------------------------

-Final SDM MOVES (3 level gauge)

barocco blast*: 2hcb + c (unguardable on the first half of the move)

sayanchiosparo*: D, D + x+y (during "the end in my hands")

------------------------------------------------------------------------

-COMBOS:


qcb + b \\ qcf + a \\ dp + y \\ rdp +x or y \\ 2qcb + x+y


qcb + b \\ qcf + a \\ qcf + a \\ qcb + a \\ qcb + a


y+a \\ qcb + b \\ qcf + a \\ qcf + a \\ 2qcf + a+b


qcb + b \\ qcf + a \\ dp + y \\ up \\ 2qcf + x+y


y \\f + x \\ dp + y \\ up \\ y \\ 2qcf + x+y


qcb + b \\ qcf + a \\qcb + a \\ 2qcf + x+y


y \\ f + x \\ dp + y \\ up \\ 2qcf + x+y


qcf + a \\ qcf + a \\ 2qcf + a+b


qcb + b \\ y \\ f+x \\ dp + x


qcf + b \\ qcf + x \\ qcb + a


qcb + y \\ hcf + a or b


y \\ dp + y \\ dp + x


qcb + b \\ qcf + b


qcb + b \\ qcb + a



 
and others...






------------------------------------------------------------------------

-STRIKER (1/2 level gauge)

Palonzo's Hit&Grab: y+a

-------------------------------------------------------

*note for barocco blast: Try this move when you have not much life...
*note for sayanchiosparo: Excute it during the last charging frame before the final hit
-------------------------------------------------------

DISCLAIMER: 
This character is for M.U.G.E.N. use only. 
I will not be held responsable for any damage done to your Computer...or your life. (muahahaha!!!)

-------------------------------------------------------
INFO about this work:
Ubu is an edited fighter, he is created with the head of Gen, the body of Fei-Long and the legs of Yamazaki,plus there are a lot of original sprites maded by me
I like very much the work done on K9999 by EI (especially for juggling) so we try to make a similar character (obviusly with a lot of difference!)
 



CREDITS:
many thanks to EI for his excellent K9999 and for giving me the authorization to use part of the K9999 code.
thanks to Elecbyte for making MUGEN
thanks to Antonio Navarra for hosting our character on his site
thanks to K3nShin for AI guard tutorial
thanks to Mugen Guild 
thanks to all mugenizers that help me to love MUGEN!

Sorry for my bad english...
For contact and suggestions visit the site: www.thephotonfalls.com




 