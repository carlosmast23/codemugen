======================| Kazuya Mishima 2.20 by chuchoryu|===========================      
Tekken 2, 4, 5, 6, TTT, TTT2 + Capcom vs SNK + Street Fighter X Tekken + Edit  by chuchoryu

This is my best character I made and my favorite like Akira Yuki from VF, now his char have a lot of tekken moves like the insane 10 hit combo from all tekken sagas, oni stomp from tekken 6

Special Thanks to:
RCT29: For make some sprites for Kazuya and for Ogre
Askuka: For make to much sprites for this character
Armentis: I use his old Kazuya model for revamp this Kazuya`s face
And you for download this character, you rocks!! really...



**Move List**

*Basic combos*

*Combo 1: LP,MP,MP

*Combo 2: LP, MP, MK, LK

*Combo 3: LP, LP, MP

*Combo 4: Back+LK, LP, MP, LK



*Special Tekken Combo: F, F + MP, LP, MP, MP, LK, MK, LP, MP, LP


*TAG: a+y
*Note: This command is only in Team Mode in mugen

*Parry*
Press only Foward (including in the air)

*Throw*
Foward + b orc or y or z

*Dodge*
a+x

*Foward roll*
a+x +Foward

*Gauge charge*
b+y

*Ushiru uraken*
B+z

*Right Split Kick*
F+b

Right & Left Split Kick*
F,F, a

*Dragon Uppercut*
F,D,DF,F, x

*Rising Uppercut* EX Properties
F,D,DF,F y  or  z

*Rising Sun* Tekken version
D,DB,B, b
*note, you can coninue to make more kicks only push continusly medium kick

*Rising Sun* Street Fighter X Tekken version  EX Properties
D,DB,B, c

*Hell Lancer* Tekken version
F,F,F A or B

*Hell Lancer* Street Fighter X Tekken version  EX Properties
D,DF,F + C

*Demon God Fist*
While Rising + y

*Demon God Fist EX*
D, DF, F + 2 Punches

*Twin Piston*
While Rising x  and continue to push y

*Entrails Smash*
DF+x
*Note: and continue to push y or b or F+y

*Hell Drop*
DF+b continue to push b or While Rising + b

*Hell sweep*
~F, D, DF, b
*Note: Continue to Push x or b,b  or b,x

*Soul Thrust*
F, F, y or z

*Lighting Screw Uppercut*
B, b+x

*Oni Stomp
D + MK
*Note, only this move perform whit P2 is in the gorund (trip)


*SFxTK Super Arts*
Use one level super gauge: D,DF,F + punch X 3

*SFxTK Cross Arts*
Use Three level super gauge: D,DF,F, b+y
*Note: If you have a partner (Tekken side) your character change in battle for your parthener (this moe is only aplied in Tekken characters or some I made using the basic Tag System)

More to come...


