---------------- CvS2 Ash Crimson ----------------
 Converted
      by
        bebop
=================================================


Date Started: 7/13/2009
Date Finish : 7/18/2009
Date Release: 12/17/2009
Updated:      01/01/2010


-------------  Movelist  ------------------------

Specials:
Crescent Sucker = Chrge+B, F,Punch
Arching Emerald Ankle = Chrge+D, U, Kick

Supers:
Excessive Emerald Ankle = D,F,DF, Kick (Level 1,2,3 super)
Thermidor Thumper = ChrgeB, F, B, F, Punch (Level 3 Super)

Moves to do left:
- Crack Counter (Rock)

-------------  Gameplay Style & Combos  ---------

Type: Charge Character
Recommended Groove: C, A, N

- I suggest using him with C-Groove because he has a nice comboability
with Lvl 2 to Lvl 1 Super Cancel on Excessive Emerald Ankle. C-Groove
is the most basic groove for basic characters.

- Use him in any groove that can roll. Because it's easier to Roll and then use his Arching
Emerald Ankle. Instead of parrying and Just Defending. It's difficult.

- Use him in A-Groove for good juggles in the corner. Roll, do an A-Groove setup to trick your
opponent, and knock them into the corner, using lots of S.HK, and fire some Crescent Sucker's
and on your last second, use a Lvl 1 Excessive Emerald Ankle

- Ash has good priority for some basic moves.
  + S.HP has quite some good range for standing only
  + S.HP is also pretty good anti air for anti-crossups and air whiffs
  + C.MP is pretty fast for crouching pokes, and is combo-able for any other special next
  + C.HP is a really good anti air, if someone is trying to cross up or air whiff
  + A.HP can link cross up into whiff combos
  + A.LK/MK has good range for pokes and exeutes fast if you're trying to hyper jump safely away
  + A.HK is fast, and usually on hit you can land another move.

- Here are some combos (chain combos into specials/supers)
  + (Cross up) A.HP--> C.LP--> C.MK-->Arching Emerald Ankle or Light/Medium Crescent Sucker
  + (Cross up) A.HP--> C.LP--> C.MK-->Excessive Emerald Ankle
  + A.HK--> C.MK --> Arching Emerald Ankle or Light/Medium Crescent Sucker
  + A.HK --> C.HP(Sweep)
------------- Special Intros --------------------

versus Ingrid, Rock, Chun-Li, Commando, Guile (same), Cammy, Juni, Juli(2 Patch), 
versus Kyo
versus Iori (coming later)
versus Rugal, Bison(Vega), Gouki, G.Rugal, Geese, Nightmare

Special Thanks:

Warusaki3,------- Thank you for allowing me to use all your resources as a template for my own needs. <3
Jin,------------- Even though you're open source, you deserve credit. For use of your sprites,
                  sounds, and everything else. Thank you so much. <3
Jesuszilla,------ Helping out with var confusions <3
LegendaryXM90,--- Coding my crappy grab and fixing part of my effects <3
KOD,------------- For walking me through on the acid effect gethits <3
DemonicKirishima- The best beta tester who helped me bring Ash to a solid polish
                  He knows what he's talking about, and helped me correct many stupid mistakes I                    made. I recommend him to anybody else who needs a trusted beta tester.
                  There were misalignments, bad CLSNs, combo suggestions, and all sorts of good                     stuff he showed me.

Without you guys this would not have accomplished this.

---- Update log---------- (Thanks for DemonicKirshima for most of these reports)

---- 01/31/2010---------------------

+ Modified Thermidor to be more useful
+ Added a juggle-comboability for c.HP if p2 is in the air
+ Added proper Fire Gethit Effects
+ EnvShake stuff removed
+ Redid some Anims
+ Redid some basic attacks
+ Redid timings for Crescent Sucker
+ Redid some CLSNs

---- 01/01/2010---------------------

+ Added Bastille Basher, my own satisfied version. I had to come up with SOMETHING different because his original
LDM was like an A-Groove sort. So I mixed it in with an Orochinagi-similarity
+ Jumping HK gravity sctrl removed (I don't know why that was there)
+ Fixed timings for s. MK, s.HK
+ Reduced some EnvShakes


---- 12/17/2009---------------------

+ Reduced the EnvShake on his trip
+ Removed EnvShake for medium attacks, but there is still EnvShake on Heavy Attacks
+ Fixed the Forward+Heavy Punch, P2 will now fall down
+ CLSNs major adjustments, fixed all of the infinite priorities for the basics, specials and supers


---- 8/13/2009---------------------

+ Air-Throw Glitch Removed. He's not supposed to have an air throw, which was causing that
floating bug where he floats off the screen. Damn you Guile.

+ Fixed Statedef 5950's HitSound timing, added EnvShake (CvS2 Cheap KO)

+ A-Groove Strength Vars Set

---- 8/08/2009---------------------(Thanks for DemonicKirshima for most of these reports)

+ Fixed A-Groove Errors with Specials

+ CLSNs redone for some basics

+ Leave Lvl 2 and Pivose Lvl 1 cancel alone. I wanted it like that. Compare that to Gouki's Gou Shoryu Lvl 2+Lvl 1 Cancel as a reference.

+ Leaving S.LK neutral because there are alternatives than just his S.LK

+ Flame Effect on MK/HK have been correctly aligned, and timed correctly

+ I made Terminal a charge move because I think it was more of a challenge to use him in that fashion. But, I understand. So, changed to classic commands.

+ I added Juni to the same intro as Ingrid, Chun-Li, Guile, Cammy, Rock, Commando, Juli (2's Patch)

+ Fixed Taunt's missing frames

+ Added new palette (DemonicKirishima) but not as the default palette.

+ Aligned the win intro effects

+ MP Ventose is fixed in alignment and velocities. Increased the velocities cuz I remember that SNK projectiles are a lot faster than CAPCOM projectiles. Iori's and Kusanagi's fireball are hella fast. If you feel that it should be faster, let me know.

+ I gave him CLK---->CMK chain.
You can also do CLP-->Light Ventose
And CMP--> Medium Ventose

+ I'm leaving EnvShakes whether you like it or not because I like it :) I like hitshakes cause it makes things look more fancy

+ Messed around with the ticks used in SLK, check it out to see if I got it right.

+ I would make Juni an intro, but... she has no special intros against anybody.

+ Added intros for Geese's, G.Rugal, Gouki's, and Bison's.

+ I cannot change the AfterImages of his High Jump because that's the way it is. I checked warusaki3's stuff and its like that too.
As a matter of fact, I customized my afterimage, but I just compared with JZ's, warusaki3, and mine, which they all execute at the same time.

+ Adjusted the LK and MK Nivose
+ HP Ventose stance fixed (I accidentally made his medium anim set as that one o_O)
+ Fixed after images on Pluviose
+ Adjusted the height on Lvl 1 Pluviose