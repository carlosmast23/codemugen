Marvel vs Capcom-Eternity of Heroes BoneClaw Wolverine by vyn
---------------------



  Controls
  --------

    Basic Controls
    --------------
      

      We will use the notation:

      D - down
      F - forward
      U - up
      B - back

      x - weak punch
      y - medium punch
      z - strong punch
      a - weak kick
      b - medium kick
      c - strong kick

 

    Standard Movement
    -----------------
      U              - Jump
      UF             - Jump forwards
      F              - Walk forwards
      DF             - Crouch
      D              - Crouch
      DB             - Crouch or low guard
      B              - Walk backwards or high guard
      UB             - Jump back
      F, F           - Forward dash
      B, B           - Back dash
      xy             - Recovery (when falling)

--------Throws---------

- a + x (when close) - Note: Hold back while grabbing to throw back

--------Technical Abilities---------

-Air Jump-

 Up (while jumping, wont work while super jumping)

-Guard Push-

 PP (while guarding)

-Ground Recovery-

 F, F while lying down

--------Ground Specials---------

-Berserker barrage-

  D, DF, F, P

-Drill Claw-

  LK+HP

-Tornado Claw-

  F, D, DF, P

-Dash Claw-

  D, DB, B, P

--------Air Specials---------

-Tornado Claw-

  F, D, DF, P

-Drill Claw-

  LK+HP

-Falling Kick-

  D,  MK

--------Ground Supers---------

-Berserker Barrage X-

  D, DF, F, PP


-Weapon X-

  F, D, DF, PP

-Fatal Claw-

  F, D, DF, KK

----------------------------------------------------------------

Credits
(in no particular order)

-Redhot
-Cloudius
-Pots
-Warusaki3
-Infinity team
-Sander71113

