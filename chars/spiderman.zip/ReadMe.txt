***Spider-Man 2.0 By SethZankuten***

 ____________________
/  Version History   \_____________________________________________________


04-28-07
 This version of spidey, is close to the MvC style of play. With the help
     of Loganir and iTorres maybe he will be finished one day.


 ____________________
/      Contents      \_____________________________________________________


   I - Introdoctions
   
  IIa - Basic Attacks
    b - Special Attacks
    c - Super Attacks
    d - Hyper Attacks
    e - Meteo Attacks

  III - Combos

   IV - Strategies

    V - Modes
   
   IV - Whats Left

  IIV - Credits


 ____________________
/  I Introductions   \_____________________________________________________


 MvC Command System - Mugen Command System

    7 8 9 - UB U UF
    4   6 - B     F
    1 2 3 - DB D DF

    J  - X
    St - Y
    Fc - Z
    Sh - A
    Fw - B
    R  - C


    -Spider-Man Difficulty Options

 To change spider-mans difficulty.
First Open "Spiderman.cns" go down to where it tells the difficulty options
Change the value of Sparkno under data and you are done!
 
 ____________________
/  IIa Basic Attacks \_____________________________________________________


   -Standing-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Jab(J), X , Combo Adder , Spidey does a quick jab attack.

     Short(Sh), A, Combo Adder, Spider man does a swift kick to the gut.

     Strong(St), Y , Medium Launcher, Spidey does a massive uppercut.

     Forward(Fw), B , Combo Adder, Spinning back kick.

     Fierce(Fc), Z, Knockback Bounce, Overhand blast that knocks the enemy far away.

     Roundhouse(R), C , Air Launcher, Sumersault backflip kick. 

   -Crouching-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Jab(J), X , Poke OTG , Spidey does a quick jab attack.

     Short(Sh), A, Poke OTG, Spider man does a swift kick.

     Strong(St), Y , OTG Combo, Backhand uppercut.

     Forward(Fw), B , Mini Launcer, Another Kick Uppercut.

     Fierce(Fc), Z, Combo?, Spinning Back Elbow.

     Roundhouse(R), C , Trip OTG, Spinning Sweep. 

   -Jumping-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Jab(J), X , Combo Adder , Spidey does a quick jab attack.

     Short(Sh), A, Combo Adder, Spider man does a swift kick to the gut.

     Strong(St), Y , Combo Adder, Spidey does a massive uppercut.

     Forward(Fw), B , Combo Adder, Uppercut with his foot?.

     Fierce(Fc), Z, Knockdown Bounce, Overhand blast that knocks the enemy far away.

     Roundhouse(R), C , Knockback Bounce, DONKEY KICK!. 


 ____________________
/ IIb Special Attacks \_____________________________________________________


   -Standing-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Web-Ball, QCF+P;236+P, Trap Projectil, Impact web-ball

     Web-Swing, QCB+K;214+K, Distance Attack OTG, Spidey swings across the stage with a DONKEY KICK!

     Spider-Sting, FDF+P;6236+P, Anti-Air, Spidey Does a Wild Shoryuken

     Web-Throw, HCB+P;63214+P, Distance Grapple, Spidey shoots a webline then throws the enemy!

     *Spider Sense(Low), QCF+Sh;236+a, Counter Attack, Crouching Counter Attack

     *Spider Sense(Medium), QCF+Fw;236+v, Counter Attack, Standing Counter Attack
   
     *Spider Sense(High), QCF+R;236+c, Counter Attack, Jumping Counter Attack

   -Jumping-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Web-Ball, QCF+P;236+P, Trap Projectil, Impact web-ball

     Web-Swing, QCB+K;214+K, Distance Attack OTG, Spidey swings across the stage with a DONKEY KICK!
            - You can follow up with 2 more webswings during superjump.

 ____________________
/ IIc Super Attacks  \_____________________________________________________


   -Standing-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Maximum Spider, QCF+PP;236+PP, Massive Damage, Classic Alley way beating

     Crawler Assault, QCF+KK;235+KK, Chipper OTG, Spidey BARRAGE!

     Ultimate Web-Throw, QCB+PP;214+PP, Mass-Damage-Throw, Round and Round you go!

     *Spider Sense Tingling, QCB+KK;214+KK, Counter, I see you!
 
   -Jumping-
     Move  ||   Command   ||  Mechanics  ||  Description 

     Maximum Spider, QCF+PP;236+PP, Massive Damage, Classic Alley way beating

 ____________________
/ IId Hypers Attacks \_____________________________________________________


   -Standing-
     Move  ||   Command   ||  Mechanics  ||  Description 

 ____________________
/ IIe Meteos Attacks \_____________________________________________________


   -Standing-
     Move  ||   Command   ||  Mechanics  ||  Description 

     *Speration Anxeity (beta), QCB+FcR;214+ZC, Trap Damage, Back IN BLACK!


 ____________________
/   III Combos       \_____________________________________________________

 Ground Magic       Stronger 

 Crouch Magic       Stronger 
                                       
 Air Magic:         ZigZag
                                       
 Super Jump Magic:  ZigZag
                                       
 Strikes:           S.Fierce
                                       
 Knockdowns:        C.Roundhouse
                                       
 Air Launchers:     S.Strong, C.Forward(mini launcher),
                                       S.Roundhouse(air launcher) 
                    
 AC Finishers:      Fierce, Roundhouse, Web Swing, Strong Air Throw


 ____________________
/  IV Strategies     \_____________________________________________________


iTorres: This is what I do----- Jump in LK, MK, SK, Web ball, Land LP, LK, MP, SK, Jump LP,LK,MP,MK, Webswing, Grapple

iTorres: I did the combo I mention earlier... the 13 hit, but instead of doing the webswing, I do the web ball

iTorres: do the air combo 2 more times and the last time.. as soon as I land, I do qcf, KK

iTorres: or I could to qcb, PP


 ____________________
/     V Modes        \_____________________________________________________


 Movie Mode Pal 6(Tobey Voice)

  -In Movie Mode spidey now has Tobeys voice. This is really just a fun pal to play so you feel like a diffrent character. Spidey will also make fun of people during the battle if he is beating them down to bad. He will also complain if he is getting beat up.

 Stealth Mode Pal 10(Invisible w/ After Images & Combo Up)

  -In this mode Spider-Man is harder to see and can combo a bit better than normal. At the expense of Maximum Spider he has gained 2 New moves.

   -Standing/Jumping-
     Move  ||   Command   ||  Mechanics  ||  Description 
     
     Spectacular Moves, QCB+P;214+P, Combo Homing Attack, Wall Crawling Action

     Maximum Assault, QCF+PP;236+PP, Massive Damage Auto Combo, Weapon X Who?

 Armor Mode Pal 11(Defense up & Super Armor)

   -Spidey's classic armor mode...Reloaded, The Web-head now has a weaker form of Juggernaugts SuperArmor but is too heavy to superjump, Also he has lost a few abilities do to this. He can no longer web swing or spider-sting but has gained alot for all he has lost.

   -Standing-
     Move  ||   Command   ||  Mechanics  ||  Description 
     
     Bounding Assault, QCB+P;214+P, Unstoppable Attack, Well? Its hard to jump in Armor

     Amazing Web-Trap , QCB+PP;214+PP, Counter Projectile, When you can't beat em' Hide

 Recover Mode Pal 12(Total Recovery)

   - Back To basics, Spidey has lost all his supers but retains his specials and combos. His Life and Power now regain at a fixed time. Also spidey can now Recover out of Combos.

 ____________________
/  VI Whats Left     \_____________________________________________________


Amalgam Hyper Needs finished
Add Missing Sprite
Get Better Sound File
More Outros/Intros
Special Outro/Intros
Opening/Ending
Tweak Some Moves
Push Back
Ground Recovery
Really Good AI

 ____________________
/    VII Credits     \_____________________________________________________


Seth Zankuten - Sound Rips, Sprites, Programing, Sprite Editing
iTorres - Video, Ideas, Beta Tester, AI Development
Loganir - Sparks, Programing Tips, Beta Tester
DJ-Van - SuperBG Graphics and Idea, Beta Tester
Samzam - Ideas, Beta Tester
SS5ACE - Sprites, Ideas,  Beta Tester
Maximof - Sound Files
Hobgoblin - Tobey McQuire Sounds
Noir
Big Eli King
Scruffy Dragons
Capcom
Marvel Comics
Stan Lee
Steve Ditko