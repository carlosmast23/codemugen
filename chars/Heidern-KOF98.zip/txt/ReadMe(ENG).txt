Heidern(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


-- Throw
Lead Belcher - F, y

Back Stabbing - F, b

Critical Drive - F or B or U, Y or B


-- Command Moves
Shooter Narnagel - F, a


-- Super Moves
Cross Cutter - (charge)B, F, x or y

Moon Slasher - (charge)D, U, x or y

Neck Rolling - (charge)D, U, a or b

Storm Bringer - F, DF, D, DB, B, x or y

Killing Bringer - F, DF, D, DB, B, a or b


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Final Bringer - D, DF, F, D, DF, F, x or y

Heidern End - D, DB, B, DB, D, DF, F, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Final Bringer - D, DF, F, D, DF, F, x or y

Heidern End - D, DB, B, DB, D, DF, F, a or b


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
fxm508
JFCT555
Kong
Ohgaki
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
