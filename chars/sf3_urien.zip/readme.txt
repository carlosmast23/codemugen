<================================================< Urien By RajaaBoy >================================================>
     
<========================< Important Notes >========================>

- Website          = www.justnopoint.com/lithues/
- Email            = litotichues@gmail.com
- Mugen Version    = 1.0+
- Character Verson = 1.1, 07-03-14, 0630

<========================< Important Facts >========================>

- This character is the property of Capcom.
- This character is fanart and shouldn't be sold since it's available for free.

<========================< Useful Tips >========================>

- This character is accurate to Street Fighter 3: Third Strike.
- This character is more accurate when fighting against other SF3 characters made with RajaaBoy's SF3 system.
- The config file contains unlisted system mechanics, so definitely read it.
- Use the config file of this character to enable/disable system mechanics.
- Press up during the super selection to disable bars without the use of the config file.
- There is a tutorial in the palette folder that explains how to add palettes.
- This character can be scaled without any graphical or mechanical problems. I prefer unscale, even though it is not accurate.
- Hitboxes are SF3 derived because SF3's boxes are mostly laughable. Mine are better. Attack boxes are accurate, but vulnerable boxes are derived. May cause slight inaccuracies, but I don't care.
- Reflection only works with Rajaa-styled SF3 characters. Too bad.

<========================< Legend >========================>

- x     = Light Punch
- y     = Medium Punch
- z     = Hard Punch
- a     = Light Kick
- b     = Medium Kick
- c     = Hard Kick

- U     = Up
- D     = Down
- F     = Forward
- B     = Back

- P     = Any Punch
- K     = Any Kick

- QCF   = Quarter Circle Forward
- QCB   = Quarter Circle Back
- HCF   = Half Circle Forward
- HCB   = Half Circle Back

- DPM   = Forward, Down, Forward
- DPMB  = Back, Down, Back

- B->F  = Hold Back, then Press Forward
- D->U  = Hold Down, then Press Up

- PPP   = Repeatedly Press Punch Buttons
- KKK   = Repeatedly Press Pick Buttons

*****The omission of any of the above ([S], [C], [A]) indicates that a move is either done while grounded or while both grounded or airborne*****
- [S]   = Done While Standing
- [C]   = Done While Crouching
- [A]   = Done While Airborne

- [*]   = Needs at least 1 Power Stock
- [**]  = Needs at least 2 Power Stocks
- [***] = Needs at least 3 Power Stocks

- $     = Charge/Hold specified button. ie: $a (hold a) ; $B (hold back)
- /     = Either/or.
- ||    = Interchangeable under certain conditions.
- >     = Continuation, not simultaneously.
- ~OR~  = Interchangeable under certain conditions.

<========================< System >========================>

- High Jump          = DU ; Press down, then quickly press up
- Forward Dash       = FF
- Back Dash          = BB
- Quick Stand        = D ; At the start of hitting the ground.
- Throw              = x + a ~OR~ x + a + F/B
- Universal Overhead = y + b
- Personal Action    = z + c
- Parry              = F + [S][A] ~OR~ D + [C] ; Against an incoming attack.
- Red Parry          = F + [S][A] ~OR~ D + [C] ; Against an incoming attack during a guard state.
- EX Specials        = Two buttons (punches or kickes) for each special performed with a punch or kick respectively.

<========================< Move List >========================>

<------------< COMMAND NORMALS >------------>

- Quarrel Punch  = F + y ; Step forward and punch.
- Quarrel Kick   = F + b ; Step forward and kick.
- Terrible Smash = F + z ; Step forward and punch.

<------------< SPECIALS >------------>

- Metallic Sphere [EX]    = QCF + P  ; Standard fireball. Chargeable.
- Chariot Tackle [EX]     = B->F + K ; Lunge forward and strike.
- Dangerous Headbutt [EX] = D->U + P ; Urien is good at hitting volleyballs with his head.
- Violence Kneedrop [EX]  = D->U + K ; Jump and kneedrop your opponent.

<------------< SUPERS ARTS >------------>

<-- INDIVIDUAL SUPER ART COMMANDS -->
- Tyrant Slaughter = QCF * 2 + P + [*] ; Multiple forward lunges.
- Temporal Thunder = QCF * 2 + P + [*] ; Fires an increasingly fast fireball.
- Aegis Reflector  = QCF * 2 + p + [*] ; Reflects projectiles.

<-- ALL SUPER ART COMMANDS -->
- Tyrant Slaughter = QCF * 2 + K + [*]
- Temporal Thunder = QCF * 2 + P + [*]
- Aegis Reflector  = QCB * 2 + P + [*]

<========================< Version History >========================>

<------------< (v.1.1) 07-03-14 >------------>

- Reflector doesn't do buggy things anymore.
- Can slam opponents into reflector now.

<------------< (v.1.1) 07-01-14 >------------>

- Reflector now reflects generic projectiles when unable to be accurate. 
- Reflector now guards against physical attacks.
- Fixed the canceling of the first hit of his elbow uppercut.
- Added appropriate sounds, including metal guard sound.
- Fixed Command buffering for canceling into charge moves.

<------------< (v.1.0) 06-29-14 >------------>

- Initial Release.

<========================< Special Thanks >========================>

<------------< Originators, Mentors, Buddies, and Contributors >------------>

- Elecbyte: Created Mugen. Mugen is supposed to be free. You shouldn't sell Mugen.
- Capcom: The origin of this character. This character is fan-art. You shouldn't sell this character.
- DreamSlayer/Just No Point : Webspace and stuff. =P
- Cyanide: Because he put me through boot camp (and the docs) to learn coding.
- Drex: Provided me with knowledge to produce my own resources.
- Laquak: He Didn't do anything.
- Dshzinetz: He Didn't do anything, either.
- Cybaster: Because every character would be Crap without his Feedback. Plus, I'm using his Readme he kindly made out of nowhere for me. Well, not anymore, but still!
- Froz: For his alternative Urien effects.

<========================< Nothing to See Here >========================>

[statedef -65536]
type = A
ctrl = 0
[state -65536]
type = null
trigger1 = 0