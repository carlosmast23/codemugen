MOTARO from (Mortal Kombat 3) Ver 1.1 100%  
Game play based on MK3/UMK3/MKT
----------------------
Author: OMEGAPSYCHO (OMEGAPSYCHO@hotmail.com) (www.OMEGAPSYCHO.webs.com)
Released: 09/01/09
----------------------

Features:

UPDATE:    08/31/2009
*- Fix Throw Bugs in team mode.
*- Fix error "kill = 0" after firs battle.
*- SND more Light with the same number of sounds.
*- alignment of some sprites.
*- A.I. TOTALLY NEW (NO SPAM A.I. ANYMORE)
*- Contains two files "Def" :     "ARCADE_size" & "MUGEN_size"
*- Supports for morphs to throws for MK1 Shang Tsung

DATE:    04/21/2009
Features  
*-Have all techniques from "MK3" "UMK3" & "MKT".
*-You can see the "Move list" pushing "START"
*-You can choose the ANNOUNCER. 
*- La I.A. is original for give more difficult for all mugen's chars.
* -Can perform 2 fatalities. (For now).  
*-The "common1 are different for emulate the MK3 version.
*-Can't perform fatality or throw the other bosses in him. (for prevent bugs and graphic garbage).
*-The code is similar in 95% from "UMK3"

----------------
Configuration (Default):
----------------
Light Punch (LP):	X
Strong Punch(SP):	Y
Light Kick (LK): 	A
Strong Kick (SK):	B
Block:	              Z
Unussles:	C
--------------
Special Moves:  (YOU CAN SEE IN THE GAME PUSHING "START")
--------------
Spark Attack    : F,D,B,HP
Grab & Pound  : F,F,HP
Teleport           : D,U
Step Foward    : F,F,LK
Super Jump     :B,B,F,HK
Tail Trip           :B+LK

FATALITY 1 : F,F,F,HK
FATALITY 2 : D,D,D,F,F,LP

Contacts
--------
Fell free to send comments and suggestions to :

OMEGAPSYCHO@hotmail.com. 

or my site:
www.OMEGAPSYCHO.webs.com

This character was made in M�xico by 
Rodrigo "Roy" Mercado Calder�n. alias: [OMEGAPSYCHO]   ;)

