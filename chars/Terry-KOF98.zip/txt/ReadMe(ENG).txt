Terry Bogard(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source(Except SFF file)

=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


*Normal Mode

-- Throw
Grasping Upper - F or B, y

Buster Throw - F or B, b


-- Command Moves
Back Knuckle - F, x

Rising Upper - DF, y


-- Super Moves
Burn Knuckle - D, DB, B, x or y

Power Wave - D, DF, F, x or y

Crack Shoot - D, DB, B, a or b

Rising Tuckle - F, D, DF, x or y

Power Dunk - F, D, DF, a or b

Power Charge - B, DB, D, DF, F, a or b


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Power Geyser - D, DB, B, DB, F, x or y

High Angle Geyser - D, DF, F, D, DF, F, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Power Geyser - D, DB, B, DB, F, x or y

High Angle Geyser - D, DF, F, D, DF, F, a or b

Buster Wolf - D, DF, F, D, DF, F, x or y


*Fatal Fury Mode(select to start + any key)

-- Throw
Grasping Upper - F, y

Buster Throw - F, b


-- Command Moves
Back Knuckle - F, x

Rising Upper - DF, y


-- Super Moves
Burn Knuckle - D, DB, B, x or y

Power Wave - D, DF, F, x or y

Crack Shoot - D, DB, B, a or b

Rising Tuckle - (charge)D, U, x or y

Fire Kick - B, DB, D, DF, F, a or b

Quick Burn - F, D, DF, x or y


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Power Geyser - D, DB, B, DB, F, x or y

Dunk Geyser - D, DF, F, D, DF, F, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Power Geyser - D, DB, B, DB, F, x or y

Dunk Geyser - D, DF, F, D, DF, F, a or b


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
fxm508
JFCT555
Kaddet
Kong
Ohgaki
Sander71113
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
