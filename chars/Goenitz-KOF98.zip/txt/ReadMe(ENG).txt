Goenitz(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


*Normal Mode

-- Throw
Meifu no Mon - F or B, y

Soukatsu Satsu - F or B, b


-- Command Moves
Ura Nagi - F, x


-- Super Moves
Yonokaze - B, DB, D, DF, F, x or a or y or b

Wanhyou Tokobuse - F, D, DF, x

Wanhyou Mametsu - F, D, DF, y

Hyouga - D, DB, B, a or b

Shin Aoi Hana: Seiran - D, DB, B, x or y(3 times)

Shin Koto Tsuki: Souga - F, DF, D, DB, B, F, a or b


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Yami Doukoku - F, DF, D, DB, B, F, DF, D, DB, B, x or y

Shin Yaotome: Mizuchi - D, DB, B, DB, D, DF, F, x or y


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Yami Doukoku - F, DF, D, DB, B, F, DF, D, DB, B, x or y

Shin Yaotome: Jissou Koku - D, DB, B, DB, D, DF, F, x or y


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
fxm508
GodRyu
JFCT555
Kong
Ohgaki
Shammahomega
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
