Kim Kaphwan(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


*Normal Mode

-- Throw
Kubikime Otoshi - F, y

Sakkyaku Nage - F, b


-- Command Moves
Dora Yup Chagi - F, x

Neri Chagi - F, a


-- Super Moves
Hien Zan       - (charge)D, U, a or b
  ->Tensho Zan - (during strong Hien Zan)a or b

Hangetsu Zan - D, DB, B, a or b

Hishou Kyaku - (in air)D, DF, F, a or b

Ryuusei Raku - (charge)B, F, a or b

Kuu Sajin - (charge)D, U, x or y

Haki Kyaku - D, D, a or b

Sanren Geki - D, DB, B, x or y(3 times)


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Hou'oh Kyaku - D, DB, B, DB, F, a or b(can use in air)

Hou'oh Tenbu Kyaku - (in air)D, DF, F, DF, D, DB, B, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Hou'oh Kyaku - D, DB, B, DB, F, a or b(can use in air)

Hou'oh Tenbu Kyaku - (in air)D, DF, F, DF, D, DB, B, a or b


*Another Mode(select to start + any key)

-- Throw
Kubikime Otoshi - F, y

Enzui Geri - F, b


-- Command Moves
Kuren Geki - F, x

Neri Chagi - F, a


-- Super Moves
Hien Zan       - (charge)D, U, a or b
  ->Tensho Zan - (during strong Hien Zan)a or b

Hangetsu Zan - D, DB, B, a or b

Hishou Kyaku - (in air)D, DF, F, a or b

Haki Kyaku - D, D, a or b

Sanren Geki - D, DB, B, x or y(3 times)


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Hou'oh Kyaku - D, DB, B, DB, F, a or b(can use in air)

Hou'oh Hiten Kyaku - D, DF, F, D, DF, F, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Hou'oh Kyaku - D, DB, B, DB, F, a or b(can use in air)

Hou'oh Hiten Kyaku - D, DF, F, D, DF, F, a or b


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
fxm508
JFCT555
Kong
Ohgaki
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
