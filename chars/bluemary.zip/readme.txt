Blue Mary by ActJapan (cvs sprites by Dampir)
"To Six" Edit by Duracelleur - 12.12.22
http://www.duracelleur.com/mugen

-------------------------------------------------------------
COMMANDS :

Specials :		~D,DF,F,P
				~D,DB,B,P
				~D,DF,F,K
				~D,DB,B,K
				~F,D,DF,K		
				
Hypers :		~D,DF,F,LP+MP
				~D,DB,B,LP+MP
				~D,DF,F,LK+MK
				~D,DB,B,LK+MK
				
-------------------------------------------------------------

http://www.duracelleur.com/mugen
++

          `.-://:`   `.:+//o.                     
        -////++ooo:  :mdhhdhh                     
       .++++++osyhh. .ho+ysyy`                    
      -+++++oshhoo:`-osy+ooss                     
      o++++++y////+oosohhhyhh-  ```               
    `++++++++ho+++++///++++oyyh++//+//-`          
   .o+o++++++y++///+s+++//////+///+so++o-`        
   +ooo++++++osoooosddhyo++++++soo++sso++o/-      
   :ydo++++++osshdmmddshhysssyhdddyyyds++++yo`    
    .hhyyyssyyyyhmmddddyyhhhhyysosyyysoooo+oo+/.  
      .-+ydddddmdddddhdysossyhddhhhhyyooo+++++os  
          `.-yhhhhhyyhddddhdddhdhhddo+ds+++++osh- 
              :shhhhyyhhhhhdhhhhhdho oo++++osyy:  
                +hddddddddmdhddhydho+o+++oss/-`   
                omdmdddmddddhhdmmNdo+++os+.       
               :yyddhdNNNdNdhmNNmmyo+oyy`         
              /hhhyyyyhyhyhhddmdmmmhhys-          
            `oyhhhhhhyyyyyyhhhddmmmd:`            
           `syyyyyyyyhhddddmmmmmmmmmh             
           +yyyyyyyhhdmmmymNNmmmmmmmm-            
           shyyyyyhdmmmh. +mmmmmmmmmmm:           
          `hhyyhhddmmmo    .smmmmmmmmmm:          
          smhddddmmmy.       `/hmmmmmNNs          
       .+dNNdmmmmNd-           `dmmmmmmh`         
      -smmNNmdhdm+.             +ydmmds`          
      ssdmmmmddm/                :dhhh`           
     `yhhhddddd/`                -dhhy+-          
      yhhhhyo+`                  `:/+o+ooo        
     `hhhh/                          .::+:        
    .oyhhm`                                       
    :o+os+                                        
   /o++oos`                                       
   :sssooo.                                       
      `.::`                                       