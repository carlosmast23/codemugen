                                      Evil Ryu by Vyn
                                      --------------


  Controls
  --------

    Basic Controls
    --------------
      

      We will use the notation:

      D - down
      F - forward
      U - up
      B - back
      
      x - weak punch
      y - medium punch
      z - strong punch
      a - weak kick
      b - medium kick
      c - strong kick
      PP - two punch buttons
      KK - two punch buttons
      PPP - three punch buttons
      KKK - three punch buttons

 
  ====>  EX - Move can be upgraded by pressing two punches or two kicks.

  ====>  AIR - Move can be executed in the air.


    Standard Movement
    -----------------
      U              - Jump
      UF             - Jump forwards
      F              - Walk forwards
      DF             - Crouch
      D              - Crouch
      DB             - Crouch or low guard
      B              - Walk backwards or high guard
      UB             - Jump back
      F, F           - Run
      B, B           - Back dash

    System Abilities
    ----------------
    
      Hold Fwd or Back (while lying down) -Roll Recovery
      Defend at the right time            -Perfect Guard


    Throws
    ------
      LP + LK Holding Fwd or Back


    Command Attacks
    ---------------

      Fwd + Y                                -Sakotsuwari
      Down + Kick (While Jumping)            -Tenmakujinkyaku

    Special Attacks
    ----------------------

      D, DF, F, P                         -Hadoken (EX) (AIR)
      D, DF, F, K                         -Ryusokyaku (EX)
      F, DF, D, DB, B + P                 -Shakunetsu Hadoken (EX) 
      F, D, DF, P                         -Shoryuuken (EX)
      D, DB, B, K                         -Tatzumaki Senpukyaku (EX) (AIR)
      DP OR RDP + KKK OR PPP              -Ashura Senku  
      

    Super Attacks
    --------------------

      D, DF, F, D, DF, F, P                  - Messatsu Gou Hado  
      D, DF, F, D, DF, F, K                  - Messatsu Gou Shoryu (LVL2) 
      x, x, F, a, z                          - Raging Demon (Requires 3 super bars) 
==========================================



    Credits
    -------

In no particular order

-Capcom for making ryu and cvs2
-PoTs: For his cvs ryu and many other cool stuff
-warusaki3 for letting me use his awesome  mugen stuff
-The dreamslayer: cvs2 rips 
-infinity mugen team: beta testing, ideas, coding etc
-Kong: cvs2 rips
-Reubenkee: for making the best ryu ever
-Acey: sprite edits
-Sumi: awesome cvs ryu
-SW: his awesome AI patch
-Many others I may have forgotten.


