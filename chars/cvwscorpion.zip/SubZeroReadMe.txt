Sub-Zero by SeanAltly
Sprites by SeanAltly
Voice by Zombie Sagat/Michael Simmons

-This is my version of Sub-Zero for Capcom vs The World. For those wondering this is the 2nd Sub-Zero, Kuai Liang. The outfit is more or less the MK1 outfit, and yes I know that was Bi-Han. However, Kuai Liang did appear in a very MK-esque outfit in MK4, hence the ninja outfit and scar. I'm not going to pretend that was intentional, though. I simply liked the look and ease of drawing of the MK1 outfit and the scar he got in MK3, so I went with that. I know there are some deisgn contradictions, but at the end of the day this is just my interpretation of the character.

Controls (Important):

A = LK
B = HK
C = G (Grab)
X = LP
Y = HP
Z = UT (Unique Tactic) - All Super commands are done with this button.

-The combo system is very loose and cancel heavy. Here are a few examples of Sub-Zero's combos:

1. LP > HP > Ice Spikes
2. LK > F+LK > HK > Ice Slide
3. C. LP > C. HP. > HK to falling opponent
4. LP > HP > HP > HK Slide > Ice Spikes
5. Ice Puddle > C. HP > J. LP > J. HK > J. HP

You get the point. Just experiment to find new chains and combos.

***MOVE LIST***

UNIQUE TACTIC:

Cold Palms - UT
 -Sub-Zero does a short range double palms trike to his opponent, accompanied by a small ice blast. Hold down UT to charge the attack for more power and range. AT full charge the move becomes ublockable.

THROW:

Body Toss - G
Forward Body Toss - F+G

COMMAND MOVES:

Hook Blow - F+LP
High Punch 1-2 - B+HP > B+HP
High Kick - F+LK
Sweep Kick - B+HK

SPECIAL MOVES:

Freeze (EX) - D,DF,F,LP
Anti-Air Freeze - D,DF,F,HP
Ice Puddle - D,DB,B,LP
Ice Clone (EX) - D,DB,B,HP (possible in air)
Ice Slide (EX) - D,DF,F,K
Cold Punishment - F,DF,D,DB,B,K

SUPER MOVES:

Polar Blast - D,DF,F,UT
Ice Spikes - D,DB,B,UT
(Level 3 Only ) Brutality - F,D,DF,UT

CREDITS:

Zombie Sagat for the voice work
Orochi Gill, Safior Kreuz, Zeckle/Laxxe23, Cazaki and Cybaster for beta testing
PotS, Mike Olbrecht, and Ryon for FX
Boon, Tobias, and Midway for creating Sub-Zero and MK
Everyone at Mugen Fighter's Guild for their continued support
Volzilla at CVG for temp hosting
You!

If I forgot you, just let me know and I'll update this!