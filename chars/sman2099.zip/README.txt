-------------------------------------------------------------------------------------------------------------------
Spider-man 2099 Mugen Character original version by Medrops relaoded by Magus 
http://www.scruffydragon.com (click on the adds ;) )
Beta Version  0.80
Got it from http://www.scruffydragon.com

-------------------------------------------------------------------------------------------------------------------
Bio
* Real Name: Miguel O'Hara
* Affiliation: Lyla, Formerly employed by Alchemax.
* Base Of Operations: His apartment at Babylon Towers (a division of Alchemax).
* Height: 5' 10"
* Weight: 170 lbs (77 kg)
* Eyes: Brown
* Hair: Brown

Miguel, an engineer of Irish and Mexican descent, worked for Alchemax. He was less than pleased at the corporation's 
vast control over the city. A genius in the field of genetics he was being pressured by Tyler Stone (Earth-928) to 
test a process to imprint genetic codes into human physiology. He reluctantly tried the process on a test subject called 
Mills. It was a faliure - Mills was transformed into a hideous creature and quickly died. This was the last straw for Miguel
he went to Stone and attempted to hand in his notice. Stone gave and Miguel accepted a drink which, unknown to Miguel had 
been laced with the highly addictive hallucinogenic drug called Rapture. As Alchemax (Earth-928) was sole manufacturer of 
the drug, Stone expected that Miguel would be forced to remain with the company. In an attempt to rid himself of the toxin, 
Miguel decided to try the genetic procedure, which had killed Mills, on himself. The process was sabotaged and he was spliced with the 
genes of a spider in the attempt to kill him (and be covered up as an 'accident'). Miguel survived the process and gained several powers.

Making a costume from a Day of the Dead (a traditional Mexican holiday) outfit, Miguel battled Alchemax and other villains as the Spider-Man of 2099
-----------------------------------------------------------------------------------------------------------------

This character Was tested on both MUGEN 1.0 and Winmugen, works on both, still old school code :P ...

----------------------------------------------
What is done? 
----------------------------------------------
Basics 
- Stance
- Turn
- Crouch
- Walk (forward/backwards)
- Dash (forward/backwards)
- Blocking
- Gethits/falling/KO
- Jump
- Jump forward/backward
- All standing punches/kicks
- All crouching punches/kicks
- All air punches/kicks
- Taunt
- Recovery roll (while knocked down just press F or B depending on what direction you want to go)
- Guard Push (while get-hit on defense D,DF + PP)
- Dizzy
- Lose by time
- Frozen state (triggered by Ice) 
- Electrocuted state (triggered by Blanka, Thor, Batman ....)
- Burned state (triggerde by Crystal, Demitri, ...)
- Throw
- 3 Intro
- 3 Win Poses
- Chain Combos

Specials
- Web-Ball     (D, DF + any P
- Web-Swing    (D, DB + any P)
- Web-Throw    (F, D, DF +  P)
- Web-Grab     (D, DF + any K) (if P2 is in the liedown state the web grabs the P2 instead of a piece of ground)
- Twister-Kick (D, DB + any K)
- Spider-Sting (F, D, DF +  K)

Hypers
- Crawler Assault     (D, DF + PP)
- Ultimate Web-Trap   (D, DB + PP)
- Huracan-Kick        (D, DB + KK)
- Ultimate Web-throw  (D, DF + KK)


----------------------------------------------
Diferences from Medrops sm2099 beta 2
----------------------------------------------
- All sprites were re-aligned.
- All CLSN on the air file was adjusted.
- Old voice from spiderman pitched up to match the new ones ripped from the game "Spiderman Shattered Dimensions".
- The old code from Erradicator's spider-man was eradicated.
- Improved common1 file.
- Combos, combos and more combos.
- Removed the 2099 strikers, the reasons is that they need to be re-sprited.
- New palettes, the old ones are on the same folder of the character, I dont like them but maybe someone do.
- It has new sprites, the quality is very noticiable from medrops work, but there is not time to fix all, If there is a chance I'll do it later.
- All specials and hypers are brand new, some similar from the regular Spider-man, but that is the idea, following the concept 
of the game of Shattered Dimensions all the Spider-men are basicly the same guy, so the moves are alike, but not the same.

----------------------------------------------
Credits and Thanks:
----------------------------------------------
* Medrops for allow me to continue his work
* Seth Zankuthen for his spiderman that I used as a fine guide :D
* Pots for leave his stuff open source and the twister kick obviusly is inspired in his Ryu hurrican kick. 
* Any other coders I wrote some names on the cns.
* Marvel for spiderman 2099
* Virtualtek for Fighter Factory. 
* Electbyte for Mugen.

Contact:
- email: maguscorp@scruffydragon.com (for suggestions or bugs report)

----------------------------------------------
VERY IMPORTANT
----------------------------------------------

Please, people owner of Mugen comunities:
- I dont like the unauthorized backups on anothers servers, I paid my own hosting and my server has the potency 
  to allow a lot of downloads, so, please dont upload this character somewhere else. Avoid that I take the decision of
  never release a newer version of the char or another of my chars, and that will be a shame because I have a 
  lot of good wips.
- Once I said that, it is useless email me for request of permissions for host my characters on another place.
- Also dont direct link to the file of my host. Link to the main page.

About Permission of use the sprites of Spider-man 2099. 
- The sprited edits, can't be used.
- Please don't steal the character code or sprites, always ask for permission, or no more public updates will appear.
- Ask nicely and maybe I'll back you up in your projects......maybe......

