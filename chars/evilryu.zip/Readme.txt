--------------------------------------------------------
-=>Evil Ryu Version  Duo 0.97<=-
--------------------------------------------------------

By Reu, and KingTigre, Aiduzzi
reuy@email.com
kingtigre@hotmail.com

Mugen Institute -=> http://mi.mgbr.net




What's left to do: 

interactivity with Evil Ken
storyboards


--------------------------------->
*This character features high-rising moves, one must have vertical scrolling stages to experience the full effect.*

What's Featured:
-------------------------------------
The first particle rendered flame surges, sparks, speckles and splash effects!
Special Meta Super Special Moves system!
The very first custom combo mode! Rage burst!
All Ryu based moves
Tonnes of original super and special moves!
Never seen before edits of Ryu, thanks to Kingtigre!
Ability to do OTG combos.
Ability to chain normal attacks!
Ability to chain normal attacks into special moves!
Ability to cancel special moves into super moves!
Ability to Super Cancel super moves into supermoves!
Combo Rating system!
Original intros, win poses and taunt!
Capcom vs SNK charge up!
Capcom vs SNK style superjump!
Capcom vs SNK flame sound, landing sound, hit sounds, block sounds, voice samples!
Capcom vs SNK 2 sound effects and voice samples!
Holy crap! Tonnes of comboability! 
-------------------------------------

More debug flood fixes, 
Infinite winpose fixed.
AI activate during team battle fixed.
Bugged Intro fixed.
Tenrai no ken corner bug fixed.



Updates:

Added effects to all lightning sprites


----------------------------------->


====================================================
<<<EXPLAINATION OF META SUPER SPECIAL MOVES>>>
===================================================
MSSMs can be performed by super cancelling into a special move which was super cancelled by another super move which was super cancelled by another super move. Simply put, they happen on your third super cancel. MSSMs also happen with a probablity of 10% whenever you do a super special move. Only Level one Super Special Moves have MSSM versions.


------------------------------------>
Extra Moves:

Air recover: 2 punches or 2 kicks while falling

Ground recover: 2 punches or 2 kicks while near ground.

Ground roll reover: 2 punches or 2 kicks while lying on ground

Taunt: Start button *(Increases defense)*


----------------------------------->
Alpha counters: Alpha counters are performed when the player does a back to down motion, followed by an attack button. Alpha counters require at least one level.

Punch counter: Ryu does a fierce shoryuken which sends his opponent flying

Kick counter: Ryu does a fierce hurricane kick


----------------------------------->
Special moves:


Jigoku Guruma: forward/backward + 2punches
If nearby opponent, Ryu will grab him and pull him along forming a wheel which gains momentum and finally releasing the opponent to be flung into the air.

Inazuma Kakato Geki: forward/backward + 2kicks (kkk rapidly)
Ryu will grab his opponent and do a series of quick punches to the head.

Hadouken: qcf + punch
Ryu gathers his internal energy and fires a ball of fire which flys across the screen.
LP does travels slowly and does one hit, MP travels faster and does two, HP goes even faster and does three.

Denjin Hadouken: hcf + punch (hold punch to charge)
Ryu charges his hadouken with surrounding chi, slowly powering up the fireball for that extra "umph". Move can be charged for more hits.

Kuuchuu Hadouken: qcf + punch (in air)
Ryu rears back and launches a fireball horizontally in mid air. Ryu's momentum in the air affects speed of fireball.

Zankuu Hadouken: qcb + punch (in air)
Ryu rears back and launches a fireball 45 degrees downward in mid air. 

Seoi Zankuu Hadouken: qcb + punch (in air) (after Zankuu hadouken)
Ryu can fire an extra hadouken if the command is done shortly after he performs the Zankuu Hadouken.

Tatsumaki Senpuu Kyaku : qcb + kick (can be done in air)
aerial Variation: hcb + kick (in air)
Ryu twirl's his body at lethal speed as he extends his leg outward to hit multiple times.
kick strength determines distance moved, hits induced and damage induced.
Perfect for air combos.

Shoryuken : dp + punch
Ryu brings his fist up and flys upwards into the air.
Ryu's basic anti air attack.

Ryuujin Kyaku: qcf + kick (in air)
Ryu will dive kick downward. Lk goes straight through, mk makes Ryu rebound after contact and hk allows Ryu to slip in a quick attack after.

-=NEW=-
Joudan Sokotou Geri: qcf + kick
Ryu thrusts his leg out in a powerful side-stepping side kick and sends his opponent flying away.

Makuu Shihai : dp + 2 punches/kicks or rdp + 2 punches/kicks
Ryu moves behind a parallel framespan.
DP makes Ryu warp forward, RDP makes Ryu warp backward. Punches makes him travel further than kicks.
A very useful move for crossups...

Zenpu Tenshin: light punch + light kick
Ryu rolls like a wild tire.
Can go through almost any attack.

Shinpou Ryu: Medium punch + Medium Kick
Ryu gathers energy from his surroundings at an accelerated rate.


------------------------------------->
Super Moves:

One Bar Super combos:

-=NEW=-
*MSSM POSSIBLE*
Metsu Joudan Sokotou Geri: hcf + 2kicks
Ryu thrusts his leg out in a more powerful side-stepping side kick and sends his opponent flying away.

*MSSM POSSIBLE*
Shin Shoryuken: qcf, qcf + kick
Ryu unleashes the ultimate dragon punch!

*MSSM POSSIBLE*
Shinkuu Tatsumaki Senpuu Kyaku: qcb, qcb + kick (directional arrows)
Ryu Does a super hurricane kick which sucks opponents in.

*MSSM POSSIBLE*
Misogi: d, d, d + kick
Ryu will transverse his physical form above his opponent to drop onto him while delivering a ki encompassed chop.

*MSSM POSSIBLE*
Kongou Kokuretsu Zan: d, d, d + punch
Ryu strikes the ground with immense force, creating an upward splash of immense energy.

*MSSM POSSIBLE*
Kuuchuu Shinkuu Tatsumaki Senpuu Kyaku: qcb, qcb + kick (air)
Ryu Does a super hurricane kick which sucks opponents in and Ryu gains mobility. Use directional arrows to move Ryu during the move.

*MSSM POSSIBLE*
Shinkuu Hadouken: qcf, qcf + punch
Ryu gathers unstable energy force and blasts it out for a random number of hits.

*MSSM POSSIBLE*
Kuuchuu Shinkuu Hadouken: qcf, qcf + punch (In Air)
Ryu gathers unstable energy force and blasts it out mid air for a random number of hits.

*MSSM POSSIBLE*
Tenma Gou Zankuu: qcb, qcb + punch (In Air)
Ryu Fires two vacuum fireballs down at his opponent.

*MSSM POSSIBLE*
Garyuu Messhuu: qcf, qcf + kick (In Air)
Ryu Does a focused dive kick which will strike the opponent with lightning force if successful.

Two bar super combos:


Three bar super combos:

Kaze No Ken: hcf + 2 punches
Ryu's most powerful move. Ryu Will pummel his opponent with one massive blow to send them flying!

-Tenrai No Ken: lp, mp, forward, lk, mk (During hit of Kaze No Ken)
Ryu's Suprise finisher for the Kaze no Ken!


Metsu Hadouken: qcb, qcb, punch (hold punch to charge)

Ryu charges up for the ultimate hadouken!
During charge up, Ryu's body is immersed in electrical force. Any contact with opponents will shock them.
Ryu can walk forward and backward during charge up
Ryu can charge up for 4 different levels of hadouken.

1 level charge causes stun.
Opponent will be rendered dizzy open recovery from hit.

2 level charge causes electrical burn.
Opponent will experience short bursts of electrical discharge for a short period of time.

3 level charge causes stun and electrical burn

Full level charge:
Ryu will reverse the flow of Chi, creating a great vacuum and releasing the greatest hadouken.

Special Modes:

CVS2 Custom combo mode: heavy punch + heavy kick






Secret Modes:

To learn this move, first you must
use the will, to drop like a gust

Show your opponent your mettle
and you will receive the medal

to unlock ryu's full potential
the combination of these two, is essential


--------------------------->
Tips and Tricks:

Ryu does not chain as well as ken, nor can he air combo. Make use of his juggling capability to rake in the hits!

Want to learn more combos? Watch his AI in action!


------------------------>

Credits: *crosses fingers, please don't let me forget anyone*

Richard Vale, AKA King Tigre: For working with me on Evil Ryu and Evil Ken, and all the kickass sprite edits.

Tenshin: For creating the ultimate ken in terms of gameplay for me to base Evil Ken on, which inturn was used as a base for Evil Ryu. Which in turn affected how I programmed Evil Ryu.

Necromancer: For the super l33t slow motion code, AI activation code, ideas and feedback.

Aiduzzi: For the lovely sprite edits.

Kamek: For permission to use that beautiful mvc2 super charge sample!

Orochi Herman: For permission to use those hitsounds, and for the idea of KO effects.

Ayu Tukimiya's creator, Arche, for the charge sprites and some hits sprites.

NESTS: For the smooth blur transition for the Tenrai no Ken

Walt: For fixing up the misogi sprites

Rabite: For the bug testing and feedback

[Rolento Virus]: For the SF3 rips :)

CuecaX: For the Super gem fighters ryu and lightning sprites.

Gousanmugen: For the blanka shocking sprites.

Sunboy: For electricity sparks which I editted.

Mugen Shank: For the bug reports, feedback and brainstorming :D

Everyone at #Mugen!! K3nshin, [E], Kyo_Kusanag, Fou_Lu, Mattasaur, KingTigre, Koga, Neogouki, Vitalzero, mugen420, Sykotik, Sunboy for rotting in IRC day after day.

All the guys at #MREV! ;)

Visual Kreations: For the Ashura warp code, as well as references to some other concepts.

Cool edit pro, what would I do without this miracle? ;p

KaoMegura: For all the excellent faqs and names of moves from the shotos.

Capcom: For all the kickass games! And from the  street fighter universe where Ryu is from.

And last but not least, God: For life

Made in Singapore!

Ciaoz! Send feedback to reuy@email.com
Come Visit us at the Mugen Institute!
*Mugen Institute -=> http://mi.mgbr.net*

Coding is fun! If Reu can code, so can you!



UPDATES HISTORY:


0.91:

Shoryuken starting lightning effects added, Thanks to CuecaX.

Added Kuuchuu hadouken, kuuchuu shinkuu hadouken

Changed zankuu hadouken command to qcb+punch, changed tenma gou zankuu as well.

Shin Shoryuken added.

Messatsu Gou Shoryu moved to hcf+2 kick command

Tweaked Kaze No Ken

Added Palletes

Working on Denjin hadouken

Basic AI added

Juggles and damage balancing

Redid MSSM garyuu Messhuu

Upgraded AI, more damage dampening

Added ring effects to Shin shoryuken. Thanks Necromancer ;)

Denjin hadouken pushed to next update.




0.97:

Fixed block damages, and fireball damages

Tweaked shoryuken startup speed

Fixed Kaze no Ken sprpriority

Fixed hurricane kick

WIP Metsu Hadouken Charge up phase and fire completed

Metsu hadouken tweaked. -more >_<



0.99:

Finally fixed AI hijacking bug. And main source of allegro bug.


Evil Ryu has gained a level!

----------

New move learned - Misogi!

----------

MSSM Shinkuu hadoukens levelled up!

MSSM Tenma zankuu hadouken levelled up!

MSSM Messatsu Gou Shoryu levelled up!

----------

Up+mp levelled up!


AI has not yet learned how to use new moves.



--------------

Tweaked all fireball hit states
Added Denjin hadouken and air hurricane kick variations
Fixed more debug floods
Redid Tenrai no Ken
Trained AI