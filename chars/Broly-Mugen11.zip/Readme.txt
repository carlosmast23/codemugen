                                           ________________________
==========================================| Broly by Mr.Ansatsuken |==========================================
                                           ������������������������
						[19.12.2019]

- Contact: facebook.com/Probopass
- Website: Ansatsukenmugen.webs.com

- Customized version of Akira Toriyama's Broly character from the Dragon Ball series.
- For Mugen 1.1+ only



===============<Features>===============

- All the essential stuff
- A huge amount of moves inspired from Dragon Ball FighterZ as well as 
  Broly's multiple movie appearances in both Dragon Ball Z and Dragon Ball Super.
- CvS-like movement
- Chain Combos, Air Combos and Super Cancels
- Tons of RGB sprites. They'll look HD no matter the resolution you're using :)
- Damage Reduction, Recovery Roll and Zero Counter, from SFZ3
- Parry and EX moves, from SFIII
- Dodge, Roll, Power Charge and Original Combo, from CvS2
- Zero Counter from the Street Fighter Alpha series.
- MAX Mode from the King of Fighter series.
- Original and edited effects from various games
- Compatible with Mugen 1.1's "Camera Zoom" system.
- Various intros, win poses and special animations
- 2 big portraits for you to choose from
- 11 Specials, 10 EXs, and 20 Super moves!
- Over 100 Palettes for you to choose from
- Pretty powerful A.I.


===============<Movelist>===============

U - Up			LP- Light punch			LK- Light kick
D - Down		MP- Medium punch		MK- Medium kick
F - Forward		HP- Hard punch			HK- Hard Kick
B - Back		P - Any punch			K - Any kick
S - Start		2P- Two punches (simultaneously)2K- Two kicks (simultaneously)

(Air)- Move must be performed in the air.
(Charge) - Charge the first button for a whole second.
(Hold) - Hold the last button to perform a more powerful version of the move.
(EX)- Move with an EX version. EX moves are performed by pressing two punch/kick buttons.

EX moves cost half of a power stock.


<NORMAL>

.Gigantic Kick:				F/B + 2K (near opponent)
.Gigantic Impact:			F/B + 2P (near opponent)


<SPECIAL>

.Eraser Shot (EX):			D, DF, F, P
.Blaster Shot (EX):			D, DF, F, P	(Air)
.Gigantic Strike (EX):			D, F, DF, P
.Gigantic Smash (EX):			D, F, DF, P	(Air)
.Lariat Express (EX):			D, DF, F, K
.Eraser Blow (EX):			D, DB, B, P
.Bloody Smash (EX):			D, F, DF, K
.Bloody Stomp (EX):			D, DF, F, K	(Air)
.Gigantic Claw (EX):			D, DB, B, K
.Gigantic Spike (EX):			D, DB, B, K	(Air)
.Powered Shell:				Start


<Lv1 SUPERS>

.Eraser Cannon:				D, DF, F, D, DF, F, P
.Gigantic Roar:				D, DB, B, D, DB, B, P
.Full Power Energy Wave:		D, DF, F, D, DF, F, P	(Air)
.Burst Eraser:				D, DB, B, D, DB, B, K
.(Aerial) Burst Eraser:			D, DB, B, D, DB, B, K	(Air)
.Gigantic Press:			D, DF, F, D, DF, F, K
.(Aerial) Gigantic Press:		D, DF, F, D, DF, F, K	(Air)


<Lv2 SUPERS>

.Eraser Shot Volley:			D, DF, F, D, DF, F, 2P
.Planet Geyser:				D, DB, B, D, DB, B, 2P
.Gigantic Meteor:			D, DF, F, D, DF, F, 2P	(Air)
.Gigantic Hammer:			D, DF, F, D, DF, F, 2K
.(Aerial) Gigantic Hammer:		D, DF, F, D, DF, F, 2K	(Air)
.Gigantic Buster:			D, DF, F, D, DB, B, 2K
.(Aerial) Gigantic Buster:		D, DF, F, D, DB, B, 2K	(Air)


<Lv3 SUPERS>

.Omega Blaster:				D, DF, F, D, DF, F, P+K
.(Aerial) Omega Blaster:		D, DF, F, D, DF, F, P+K (Air)
.Gigantic Omegastorm:			D, DB, B, D, DF, F, 2P
.Blaster Meteor:			D, DB, B, D, DB, B, 2K
.(Aerial) Blaster Meteor:		D, DB, B, D, DB, B, 2K	(Air)
.Gigantic Catastrophe:			LP, LP, F, LK, HP / D, DF, F, D, DF, F, Start


<TEAM Lv3 SUPERS>

.Omega Spirit Cannon:			D, DB, B, D, DB, B, P+K (While fighting alongside Bardock by DJMouF and I)
.Omega Kamehameha:			D, DB, B, D, DB, B, P+K (While fighting alongside Goku by DJMouF)
.Omega Galick Gun:			D, DB, B, D, DB, B, P+K (While fighting alongside Vegeta by DJMouF)
(WIP)	.Omega Masenko:			D, DB, B, D, DB, B, P+K (While fighting alongside Gohan by DJMouF)
(WIP)	.Omega Ox Cannon:		D, DB, B, D, DB, B, P+K (While fighting alongside Chi-Chi by Ohgaki and I)

<SYSTEM>

.Back Dash:				B, B
.Forward Dash:				F, F
.Dodge:					LK + LP
.Forward Roll:				F + LK + LP
.Backward Roll:				B + LK + LP
.Parry High:				(Tap) F
.Parry Low:				(Tap) D
.Air Parry:				(Tap) F (Air)
.Power Charge:				MK+MP  (Hold)
.Custom Combo:				HK+HP  (Can also be done in the air)
.Zero Counter:				B, DB, D, P/K  (During standing or crouching guard)
.Fall Recovery:				2P (While falling when hit)
.Recovery Roll:				2K (While falling when hit)
.Low Jump:				U (Tap)
.High Jump:				D, U
.Taunt:					Start



===============<Move Details>===============

- Bloody Smash ignores most projectiles before contact.

- Powered Shell breaks after getting hit 3 times. However, the A.I.--Boss version of Broly will not only last longer,
  but also break after 5 hits!
  The amount of hits that it takes to break it will DOUBLE while fighting Infinite's Deadpool or Dr. Dooom.

- Gigantic Catastrophe is completely invulnerable, but it can be punished if it misses.

- Bloody Smash, Blaster Shot, Bloody Stomp, and (Heavy) Eraser Shot can hit lying-down opponents.
  The same applies to Burst Eraser, Full Power Energy Wave, Planet Geyser, Gigantic Meteor, and Blaster Meteor.

- Most EX Specials have a couple frames of Armor, and the ones that don't, have a couple frames of invincibility against Normal attacks.

- Gigantic Press, Gigantic Hammer, Gigantic Buster and Omega Blaster goes through projectiles.

- Although Gigantic Omegastorm is unblockable, if the player blocks the first hit, the rest of the attack will deal 1/3 of the regular damage.
  Which is about as strong as an EX attack.
  Gigantic Omegastorm cannot be parried, but it can EASILY be dodged, even with a backwards-roll.

- Gigantic Strike, Gigantic Spike, EX Gigantic Strike, EX Gigantic Spike and EX Gigantic Claw
  can be combo-ed into Full Power Energy Wave or Gigantic Meteor.

- Gigantic Hammer can be cancelled into Gigantic Meteor right before the last hit.


===============<DRAMATIC FINISH!>===============

In this current version, Broly only has 1 Dramatic Finish, which can be triggered when he's defeated by specific versions of Goku.
The current Goku(s) compatible with this are...

- Goku by DJMouF
- Goku by Vyn
- Goku by Team Z2
- SSJ Goku by Team Z2
- Goku by 280Gou
- Goku by CobraG6
- SSJ Goku by CobraG6

The only characters that don't requiere patching are DJMouF's version and Vyn's most recent version.
For the patches (for the other characters), please refer to the "DRAMATIC FINISH PATCHES" folder.


===============<Other Info>===============

<<<<<Selecting the win pose>>>>>

LK -> Broly laughs for a few seconds
MK -> Broly says "As expected, trash will always be trash!" in Japanese
HK -> Broly says "Ore wa bakemono...? Chigau, ore wa Akuma da!"
      ("I am a monster, you say...? Wrong, I am the Devil!")
LP/MP/HP -> Broly charges his power while screaming, distorting the colors in the enviroment.


<<<<<Customizing the character>>>>>

Broly's Config.txt file changes many of Broly's features, including...
- Camera-Zoom usage
- Chain Combos / Air Combos
- Super Cancels
- Hitsparks
- Hitsounds
- Palette Selector and Custom Combo / MAX Mode Selector
- Super Finish music
- Special Finish


===============<Version History>===============

<19.12.2019>
- Powered Shell will now be destroyed by receiving any direct-contact hit (like in Dragon Ball FighterZ).
  This change, however, doesn't apply to the A.I. 'cause git gud.
- Modified the Aura effect in his Power Charge.
  Now it will grow bigger as he gains more power! Haha.
- Made him compatible with add004.
  (Now his aura and lightning will no longer appear while he's not fighting, in the background).
- Fixed the enviroment-lightning effect during the cinematic intro in stages with Zoom permanently enabled.
- Slightly improved the visuals of the Omega Blaster in the Mugen 1.1 version.
- Fixed a bug that made Broly's A.I.'s Gigantic Claw impossible to connect (on the previous version only).
  (Which made his Boss Battle easier and exploitable...).
- Fixed Broly's Dragon Ball FighterZ intro in stages with Zoom permanently enabled.
- Fixed a glitch that made Broly's Eraser Blow have a messy palette in the 1.0 version.
- Several changes made long ago, that I've forgotten to mention lol.
- Slightly improved A.I.
- Minor changes / bug fixes.

<04.07.2019>
- EX Moves now take only 1/3 of the MAX Gauge during MAX Mode.
- Crouching Hard Punch becomes a MvC-like launcher when Air Combos are enabled!
  This opens the gate to a whole new bunch of combo-possibilities!
- Fixed the FX of Gigantic Catastrophe in stages that had Camera-Zoom enabled.
- Slightly improved the visuals of Gigantic Omegastorm
- Gigantic Spike can now be cancelled during Custom Combo
- Burst Eraser can no longer be cancelled from Gigantic Buster
- The cinematic intro will no longer cause glitches in stages with Zoom permanently enabled.
- Using any EX move will end the Custom Combo state.
  (Some EX moves previously didn't).
- Improved the Zoom effect during the vs Goku Dramatic Finish.
- Updated the Dramatic Finish patch for 280gou's Son Goku.
- Fixed the debug flood in most moves.
  (Except the ones where it was just wayy too complicated to fix;
   Burst Eraser, Blaster Meteor, Gigantic Meteor and Omega Blaster)
- Minor changes/bug fixes.

<23.06.2019>
- Removed an infinite combo that happened by connecting
  EX Eraser Shot -> Dash -> LP -> MP -> EX Eraser Shot -> Repeat.
- Quite a small update indeed, but a necessary one regardless.

<22.06.2019>
- Fixed a rather huge glitch with the Bio-Broly palette.
- Time Over can no longer happen during most Lv3 Supers.
- Fixed the Special Guard Spark in the Mugen 1.0 version.
- Jabs and Light Kicks can no longer hit falling-down opponents.

<22.06.2019>
- First Release.


===============<What's Missing>===============

- A run animation for Gigantic Catastrophe.
- Special interaction animations (Shock, Midnight Bliss, etc)
- More DRAMATIC FINISHes (maybe?)
- More Intros (?)
- More Win poses (?)
- Perhaps more moves from Dragon Ball Super: Broly, if there's ever enough sprites for that.
- An English voice set(?) #IStandWithVic
- A Spanish voice set(?) (... Ahora te mandar� al otro mundo!)


=====<Special Thanks>=====

- BoyBoyz and G.Knux19, I took a lot of inspiration from their Brolys.
- DJMouF, since his original work for Goku and Bardock are what inspired me
  to make Broly in the first place, haha.
- Speedster, for the godly color-separation! ;D
- CobraG6, since I took a lot of effect ideas from his DBZ chars (mostly Vegeta).
  Broly's aura, especially, was extremely inspired in CobraG6's Vegeta.
- Infinite, for the Palette Selector (and effect ideas, etc).
  Also for sending me his color-separated .SFF of Broly!
- DivineWolf, for the MAX Mode.
- Beterhans. If it wasn't because of him, the Mugen 1.1 version wouldn't have
  any of those tasty ZOOM mechanics. I can't thank him enough, lmao.
- Vyn, 'cause I also took a ton of inspiration from the godly effects on his Goku.
  ESPECIALLY for the Gigantic Omegastorm!
- Phantom.of.the.Server again for... you know.
- Isair-Dragneel and DivineSprites, for drawing the DBS Broly and SSJ1 Broly sprites (respectively).
- Everyone who has ever supported my work. I decided to finish this char just because of you.
- The Mugen Fighters Guild along with the MUGEN community, for making most of Broly's palettes!
  And also for their (upcoming) feedback, heh.
  (Even if I don't update the char, haha)
- Elecbyte, for creating M.U.G.E.N.
- Vituall Tek, for creating Fighter Factory.
- Adobe and the Audacity Team, for creating both Photoshop and Audacity, respectively, hehe.
  (Which I used every time to edit all Visual/Sound effects, heh)
- Those who I forgot to mention <:D (Is there anyone...?)
- God.
- You, for downloading my char! :D


=====<Disclaimer>=====

- Broly�, Dragon Ball�, Dragon Ball Z�, Dragon Ball GT�, Dragon Ball Super�, Dragon Ball Z: Broly - The Legendary Super Saiyan�
  Dragon Ball Z: Broly - Second Coming� and Dragon Ball Super: Broly� are property of Akira Toriyama and Toei Company Ltd.
- Dragon Ball Z: Extreme Butoden� and Dragon Ball FighterZ� are property of Bandai Namco Entertainment Inc.
- Capcom vs. SNK� is property of Capcom�. 
- This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes.