
____________>>>>>>>> THE MIGHTY THOR - God of Thunder <<<<<<<<<<_______________________
	By LOGANIR (weapon.x@ig.com.br)  &  BLACK DRAGON (wbbio@ig.com.br)  

0.93 version - 01/01/2006       DOS & WINMUGEN  COMPATIBLE

*GAMEPLAY:  VS style... but not at all,  Some custom stuff :P
*NOTE: The sparks style and game play don�t reflect the ones used on the final game projects (MvsC3 / DCvsM)

=========================================================================================
Name - The Mighty Thor
Game origin -  Edits from Alex - Dr. Doom - Sabretooth - Cable - Leo - Venom...etc
Version - 0.93
Character design by Loganir
Sprite editor - Loganir & Black Dragon
Programmer - Loganir 
=========================================================================================

TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
UPDATE 0.93 release
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

- Added custom continue screen... Dark norse goddess of death, Hela.
- Added 1 new intro.... "Mjolnir portal"
- Added 2 new winposes.... "Odin my father" & "Thundergod"
- Added custom WinKO finish effect
- Added some new fx (dust, hitwall, ground land ) 
- Added Hit Wall codes in some attacks - thanks to DG & SMI
- Added  cancel dash with basic stand attacks like VS series (except for Hammer crush command)
- Added Negative Edge for specials...  ( 2 buttons hypers still missing) =P
- Added 2 in 1 combo system for attacks
- Adjusted  Combos and only Thunderstrike can be canceled into hypers now
- Adjusted aerial Combo dynamics 
- Fixed aerial Dash... works now after basics 
- Fixed  Anim 800 without colisions
- Fixed loop sounds from Thunderstrike & Tear of the sky (other sounds too)  
- Fixed Rain explode, now triggers if P2  Y>= - 150  and  the BG palfx persist if Thor Hypers are used
- Fixed Bifrost break helper for reversals and combo cancel chain only if hits
- Fixed P2 bar for the Mystic Rainfall Hyper....shows in the right side now
- Fixed Mjolnir Launch...and now Thor can be throw
- Removed infinite  dash>wp>mp
- Tweaked hyper Nordic rage, spins more fast 
- Tweaked hyper  W.O.A,  P2 custom states and sounds ( NOTE: dont work properly without tag battle characters in team mode)
- Tweaked the A.I. and added a easy version, change in the def file if you wish
- Tag battle code now can be removed,  change in the def file if you wish

TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
WHATS LEFT:
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

still......
- Fix any bugs reported and Tweaking some stuff
- Code optimization
- Tweaking the WOA and the hypers/superarmor
- Tweaking tag battle mode
- Rework Mjolnir launch code: 3 way directions and like Caps shield, helper in the gethits
- Dizzy system
- Special Hammer typhoon
- More Hyper portraits
- Intro & Winpose with Thor versions (Walt simonson battle armor, Odinforce Thor etc...)
- Intro & Winpose special against Wonder Woman
- Midnight Bliss (Thorgirl/Tarene, the chosen maybe)
- Some JaguarHX suggestions (and there�s a lot :P)

and only one of these hypers for each version:
- Hyper Rune king Thor, ultimate move 2	_______	(Solo version) 	
- Hyper for the Avengers team______________	(MvsC3 project)
- Hyper Amalgam - Thorion of Asgods________	(DCvsM project)  


TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
WHATS DONE:
0.91 release
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
- All basic attacks and stuff
- 4 intros (1 for Flash by Erradicator & Black Dragon, still needs some work)
- 1 hyper portrait
- 1 portrait
- 3 win poses
- Voices from 90's Cartoons by John Rhys Davies and some he did for LOTR games
- Sparks MVC2 custom and similar FX edited from others games
- 1 Taunt
- Super Jump
- Chain and Air Combos
- Flying mode
- 7 Specials 
- 6 Hyper/Supers 
- 6 palettes 
- A.I.
- Tag Battle implemented for team arcade mode 
- Recovery Roll
- Guard Push
- Counter
- Intro arcade
- End arcade


TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
COMMAND LIST - see the intro arcade with command sheet for more details
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

-------------------------------------------------------------------------------
*SPECIAL MOVES 
--------------------------------------------------------------------------------
- HAMMER CRUSH   "Hammer klemme"
F,F + Z

- MJOLNIR IGNITION (hold to build up energy)   " MJ�LNIR ANTENNING"
D,DF,F and HOLD X or Y or Z  

- MJOLNIR LAUNCH " MJ�LNIR Innlede"
D,DF,F + X or Y or Z

- THUNDER STRIKE  "Tordenet Streike"
D,DB,B + X or Y or Z

- AESIR RISING HERO  " Aesir Stiger helt" 
F, D, F + X or Y or Z

-BIFROST BREAK      "det stor Bifrost breat av"
D, DF, F + A or B or C

- GUNGNIR DIVE (only on air) " Gungnir dykke"
D,DF,F + A or B or C

- AESIR MISSILE (only on air)  "Grundig raketten"
D,DF,F + X or Y or Z

-COUNTER (at least 1 full power bar)
On block  use  B, DB, D  + X or Y or Z

- RECOVERY ROLL
B, DB, D  + A or B or C

-GUARD PUSH
On block  use  2 punches

- FLYING MODE
D,B + 2 kicks

-------------------------------------------------------------------
*HYPER/SUPER MOVES
-------------------------------------------------------------------
- TEAR OF THE SKY (Hyper ThunderStrike)  " T�re fra himmelen"
D, DB ,B + 2 punchs

- MYSTIC RAINFALL  "Hemmelighetsfull regn falle" 
F, D, F + 2 kicks

- MIGHTY URU COMET  "Mektig uru Komme"
F, D, F + 2 punchs

-NORDIC RAGE  "Nordic raseri" 
D, DF, F  + 2 punchs

-RAGNAROK HAMMER  "Ragnarok hammer :P "
D, DF, F  + 2 kicks 

- WARRIORS OF ASGARD (Level 3 hyper, unblockable)  " Det Kriger av Asgard "
D, DB ,B  + punch + kick



TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
CHARACTER PROFILE & BACKGROUND
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

To understand who are the God of Thunder, a little pick from the Norse Mythology version
and the Marvel version. 
_________________________________________________________________________
MYTHOLOGY VERSION:  The son of Odin and Jord.  Thor is the god of thunder and
lightning, which he unleashes with each strike of his hammer, Mjolnir.  He is
the most powerful of the gods, even surpassing Odin in strength.  He is a
large, muscular man with a red beard and eyes of lightning.  One of the most
popular gods as a protector of both gods and humans alike, he surpassed Odin
in popularity because he didn't require human sacrifices.  And also unlike
Odin, he was much more trustworthy.  During Ragnarok, he will kill Jormungand,
the Midgard Serpeant, but will also die from it's poison.  He is married to
Sif, a fertility goddess, and his symbol is the Swastika. (Don't give me that
look!  It's true!)
FROM: Gamefaqs - Norse Mythology by Hexum - nixhexus@yahoo.com / Valkyrie Profile section
_______________________________________________________________________________________________________
MARVEL VERSION: True to his mythological foundation, the comic book Thor was not what one might consider a "quick study." 
The Son of Odin, though overflowing with bravery and determination, lacked the intelligence and wit to save himself from 
dastardly plans in both the myths and in the comics.

Thor could not possibly blend with other heroes of Marvel continuity without first donning a standard costume; to create 
the proper appearance for the mighty Thor, artist Jack Kirby researched the tales surrounding the Norse god. A dominant 
feature of Thor's costume was his helmet, which featured the large wings of an eagle. Clearly, eagle wings were widely 
recognized as symbols of Viking warfare; perhaps Kirby saw these artifacts and was inspired to design Thor's helmet in 
such a fashion. 
Perhaps Thor's most important costume specification was his red cape, which placed him high above the other early heroes 
in the Marvel Universe; the major Marvel heroes in the early 1960s, all performed their duties without wearing capes. 
By donning the red cape, Thor automatically achieved a regal status, reminiscent of royal robes or, indeed, the costume 
of DC Comics' popular Superman. 

In the comic book series, Thor never acts "holier-than-thou," because he understands that he is not the dominant force in 
reality; perhaps the greatest example concerning Thor's rank as a soldier (and not a king) would be to examine his 
relationship with his father, Odin. 
Writer Stan Lee explains, "Thor's powers allow him to operate on a grandiose, cosmic scale, yet the old Norse tales that 
Marvel adapted demanded that he be subordinate to an even greater force. Odin, the virtually omnipotent leader of the 
legendary gods, is Thor's father, and he rules with an iron hand. 
Many comic book heroes are orphans, inspired to fight crime because of the death of their parents, so Thor's somewhat 
awkward position as a dutiful son sets him apart"

THE POWERS OF THOR:
*Weather Control: By tapping the magical enchantments of his hammer Mjolnir, Thor can summon all storm elements.

*Strength: Thor can lift upwards of 100 tons, putting him in Marvel�s elite class. He also has incredible endurance,
resistance to virtually all sickness and disease and can withstand and heal practically any wound.

*Inter-dimensional Travel: Mjolnir can open inter-dimensional portals, allowing Thor to travel between Earth, Asgard
and other realms.

*Fighting: Thor is a highly skilled warrior who has had many centuries of battle to perfect his craft.
 
*Flight: Thor`s hammer, Mjolnir, is the vehicle through which Thor "flies". By throwing the hammer
and grabbing on to its mystical leather thong, Thor is propelled by the hammer into flight.

From Wizard Magazine 80, April 1998
________________________________________________________________________________



TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
Credits and Thanks:
So much people.....forgive me if I forgot someone : P
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
=======================================================================
LOGANIR:
=======================================================================
- The true and only GOD, for giving me inspiration everyday  \o/
- Elecbyte for Mugen
- Marvel Comics:
StanLee, JackKirby, WaltSimonson, JohnBuscema for the great inspiration works for Thor
- BlackDragon, partner :) for the great help and work on the edit and concepts

- MVSC3 Mugenesis team,  DCvsM team and  WarmachineMadness forums in special:
Buyog,  Magus,  Midnight Spirit, SuperVenom, WarmachineX for the feedbacks and backups 
- People on MGBR & MFG forums for the bug reports, thanks a lot.

- Anubis for some great sound effects and feedback 
- Chris Vaughan for the best Thor site on net, all John Rhys Davies voices come from there  http://www.immortalthor.net/
- DG for the feedback and tips, also liberated his chars for reference... Mjolnir isolating P2 closer are based on Ryu, thanks to GGN too for the concept! :)
- Erradicator for some Cable Hitsparks and feedback, also give me help with super armor codes... thanks man!
- IxnayDK for the feedback and tips for Thor work on LinuxMugen
- Ilusionista for the feedback and help with mythological stuff names, also a lot of suggestions for moves and bases
- JaguarHX for the brainstorm ideas and suggestions for Thor, I want implement some for the final release 
- McCready for the WinKO bg effect and feedbacks... thanks!
- Phantom.of.the.Server for the great tips and feedbacks, also give me some code to work on...thank you man! :)

- Flowagirl/Necromancer for the tutorials  archive codes from: http://blargh.i-xcell.com
- RyouWin for the Tag team Battle codes for MvsC3, thanks man!
- SodonHid for the breaking wall code on MGBR forum archives
- Soldats/MysticBlaze for the tutorials archive codes from is site

- DeeJack and Danielps for some MvsC2 rips (DrDoom and FX)
- DreamSlayer for the Cvs2 spritepacks (Joe,Chang) 
- Hoshi`s for some EFZ FX rips open source pack, I use some FX from there
- Joram Zwei fuss for the  rips from SF3/Alex packs... the main base for Thor, big thanks
- Kung Fu Man for the Leo(CFJ) taunt and objects from NxC... plus MvsC2 rips, I use some RubyHeart and Cable stuff
- New and ZantetsuMUG for the Tohou rips open source pack, I edit some FX from there
- Xenozip & Blip for the GGXX rips open source pack; I use some FX from there  
Yes, Thor its a milkshake of effects :P

- Those who I forgot to mention now 

===============================================================================
BLACK DRAGON:
===============================================================================
- For all good things God give me in my life
- Elecbyte for Mugen
- All Mugenesis members and MVSC3 team for the feedbacks
- Everyone up there mentioned by Loganir for the help  
- JaguarHX and Erradicator for all ideas and incentive 
- My brother, always suggesting and cheer me up
- And Loganir for accept my help on the edit work  :)

TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT
Thor created with the Tools:
Photoshop, Gamani Gifmoviegear, Susie, Fighter Factory, MEE v0.39, Zcharcad 7, Kawaks, NeroWaveEdit 
TTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT

* THIS CHARACTER CAN'T BE USED FOR ANY COMMERCIAL PURPOSES!!!!!!!
* Thor are property of Marvel Comics 
* Some graphics are property of Capcom, Sammy and Tasofro 

*Mugen people..... Do not host the character without previous authorization,.and about permissions 
or anything related to the character:
weapon.x@ig.com.br
;)