                           ____________________________________________
==========================| Pocket Shin Gouki by Phantom.of.the.Server |=======================
                           ��������������������������������������������       [14.01.2010]

- Contact: potsmugen@yahoo.com.br
- Website: http://www.mugenguild.com/pots/

- Customized version of Capcom's Gouki character, from Pocket Fighter
- For Mugen 1.0 only



=====<Features>=====

- All the essential stuff
- Crossover series Super Jump and Combo system
- Alpha Counter and Power Charge
- Pocket Fighters Run and Dash
- Cancel and Super Cancel
- Many edited sprites, giving that M.U.G.E.N. char feeling :D
- Various intros and win poses, special animation for "Continue?", "Draw Game" and "Time Over"
- Intro versus my Ryu :D
- Effects mainly from Pocket Fighters and Crossover series plus M.U.G.E.N.'s potential
- Voices from PF, SFA3 and CVS2
- All of Gouki's moves, seen in many other games (well, almost :P)
- A.I.
- 12 palettes



=====<What's Missing>=====

- Fixing this Readme, definitely :P



=====<Movelist>=====

U - up          x - weak punch         a - weak kick
D - down        y - medium punch       b - medium kick
L - left        z - strong punch       c - strong kick
R - right       p - any punch          k - any kick
s - start       2p- two punches        2k- two kicks


---<Normal>---

.Zugai Hasatsu  /  Skull Destroyer:
    - F + y

.Headbutt:
    - z   (during Run)

.Zenpou Tenshin / Roll Body Forward:
    - D, DB, D, p

.Seoi Nage / Over-the-shoulder Throw:
    - F or B + 2p   (close to the opponent)

.Tomoe Nage  /  Overhead Judo Throw:
    - F or B + 2k   (close to the opponent)


---<Special>---

.Gou Hadou Ken / Great Surge Fist:
    - D, DF, F, p

.Zankuu Hadou Ken / Air Slash Surge Fist:
    - D, DF, F, p   (in the air)

.Gou Shoryuu Ken / Great Rising Dragon Fist:
    - F, D, DF, p

.Shakunetsu Hadou Ken / Scorching Heat Surge Fist:
    - F, DF, D, DB, B, p

.Zankuu Hadou Ken / Air Slash Surge Fist:
    - D, DF, F, 2p   (in the air)

.Tatsumaki Zankuu Kyaku / Sky Slashing Tornado Kick:
    - D, DB, B, k

.Kuuchuu Tatsumaki Zankuu Kyaku / Midair Sky Slashing Tornado Kick:
    - D, DB, B, k   (in the air)

.Tenma Kuujin Kyaku  /  Demon Air Blade Kick:
    - D, DF, F, k   (in the air)

.Ashura Senkuu Zenpou / "God of War" Air Flash Forward):
    - F, D, DF, 2p or 2k   (2p travels further)

.Ashura Senkuu Kouhou / "God of War" Air Flash Backward):
    - B, D, DB, 2p or 2k   (2p travels further)

.Hyakki Shuu  /  Pandemonium Attack:
    - F, D, DF, k

.Hyakki Gouzan  /  Hundred Demons Great Slash:
    - do nothing   (during Hyakki Shuu)

.Hyakki Goushou  /  Hundred Demons Great Collide:
    - p   (during Hyakki Shu)

.Hyakki Goudan  /  Hundred Demon Great Cutting:
    - k   (during Hyakki Shuu)

.Hyakki Gousai  /  Hundred Demons Great Smash:
    - F or B + p   (during Hyakki Shuu and close to opponent)

.Hyakki Goutsui (Hundred Demons Great Crash)
    - F or B + k   (during Hyakki Shuu and close to opponent)


---<Lv.1 Supers>---

.Messatsu Gou Hadou / Great Surge Deadly Attack:
    - D, DB, B, 2p

.Tenma Gou Zankuu / Demonic Great Air Slash:
    - D, DF, F, 2p   (in the air)

.Messatsu Gou Shoryuu / Great Rising Dragon Deadly Attack:
    - D, DF, F, 2p

.Messatsu Gou Rasen / Great Spiralling Deadly Attack:
    - D, DB, B, 2k

.Kuuchuu Messatsu Gou Rasen / Midair Great Spiralling Deadly Attack:
    - D, DB, B, 2k    (in the air)


---<Lv.3 Supers>---

.Messatsu Chou Hadou / Super Surge Deadly Attack:
    - F, DF, D, DB, B, 2p

.Tenma Gou Zankuu Kouu / Demonic Great Air Slash Rain:
    - B, DB, D, DF, F, 2p   (in the air)

.Kongou Kokuretsu Zan  /  Continent-Destroying Vajra Slash:
    - D, D, D, 2p

.Misogi / Purification of Mind, Body and Spirit:
    - F, DF, D, DB, B, 2k

.Shun Goku Satsu  /  Imprisioning Death Flash: 
    - x, x, F, a, z


---<Miscelaneous>---

.Back Dash:
    - B, B

.Forward Dash:
    - F, F

.Run:
    - F, F (hold)

.Launcher:
    - D+z

.Super Jump:
    - D, U   or   U   (during Launcher hit)

.Power Charge:
    - b+y   (hold)

.Zero Counter (Gou Shoryuu Ken):
    - F + 2p   (during standing or crouching guard)

.Zero Counter (Tatsumaki Zankuu Kyaku):
    - F + 2k   (during standing or crouching guard)

.Fall Recovery:
    - 2p   (while falling when hit)

.Chouhatsu:
    - s

.Special Taunt:
    - D, DF, F, s


	
=====<Version History>=====

<14.01.2010>
- For Mugen 1.0 now

...

And lots of undocumented versions. ;P



=====<Special Thanks>=====

- Byakko, Fuze, IxnayDK, Loona, Winane, Z Sabre User, for useful feedback
- Winane, for the tips on A.I.
- Synk, for helping me with the move names translations
- Jennifer and Erradicator, for the super charge effects
- Mugenesis and The Mugen Fighters Guild people for the support
- Those who I forgot to mention :P
- You, for downloading my char ;)



=====<Disclaimer>=====

- Gouki and Pocket Fighter are property of Capcom
- This Mugen character is a non-profit fan work, it cannot be used for any commercial purposes