Name: kuando
Age : 39 
Height : 195 cm
Weight : 95 Kg
Nationality : Austria (Japan by his Mother)
Combat Stile: Pseudo-Tekken Style
What she likes: His body
What He dislikes : Fat people
He looks like : a KOF character

---------------------------------------------------------
What's done:(ver.1.5)

What's Done:

super charge vs ubu,ella,kuando,giano
new cns fix
new cmd fix
new air fix
many many fix


----------------------------------------------------------
-throws & grabs:

fwd + y
fwd + b



-look at my elbow:

f+x


-super charge:(only vs ubu,ella,kuando,giano)

D,DF,F c

-special charge:

D,DF,F c

------------------------------------------------------
SPECIALS:


-Godrano Punch(x):
B, DB, D, DF, F, x


-Godrano Punch(Y):   (unguardable)-----------------------new!
B, DB, D, DF, F, y 

followed by

-Teleportino (during Godrano Punch Y)
D, DF, F, y



-Stomachevole Punch:
F, D, DF, x or y



-Tettonico Punch:
D, DB, B, x or y



-Presaspeciale: (when close)
F, DF, D, DB, B, F, x or y


 

-Ti Prendo in aria: (p2-->air)
D, DB, B, a or b



-Fisto(a): ---> to ---> Imminent Dog Stand
F, D, DF, a 

-Fisto(b): 
F, D, DF, b

-------------------------------------------------------

-IMMINENT DOG STAND:
B, DB, D, DF, F, a or b


-Un Due Tre!: (during Imminent Dog Stand)
x, x, x

-Quattro Cinque Sei!: (during Imminent Dog Stand)
y, y, y


-Presa In aria: (during Imminent Dog Stand)
a, a, a


-The Wall: (during Imminent Dog Stand)
b, b, b,

-Roll: (during Imminent Dog Stand)
z

-Cancel Stance: (during Imminent Dog Stand)
B

--------------------------------------------------------


-BOXING STANCE:

 D, D,  a or b (during boxing stance)

-destrega:  (during boxing stance) 
a,a,a

-sinistrega:  (during boxing stance)
b,b,b

-Crossline from The Hill:  (during boxing stance)
x,x,x or y,y,y

-dash: (during boxing stance)
F,F

-Cancel Stance: (during boxing stance)
B
--------------------------------------------------------

SUPER(level 1 gauge):

-TANTIPUGNI:
D, DF, F, D, DF, F, x or y


-HORATIMENO:
D, DF, F, DF, D, DB, B, x or y


-TALKING HEAD: (when close)
D, DB, B, D, DB, B, x or y


-AORISTO PUNCH: (during Imminent Dog Stand)
D, DF, F, D, DF, F, x or y


-PODOROSO:
D, DF, F, D, DF, F, a or b (during boxing stance)

----------------------------------------------------------
SUPER(level 2 gauge):

-PROPRIOTANTIPUGNI:
D, DF, F, D, DF, F, x+y


-HORATIMENODIPIU':
D, DF, F, DF, D, DB, B, x+y


TESTEDICOCCO: (when close)
D, DB, B, D, DB, B, x+y


-PERFETTO PUNCH: (during Imminent Dog Stand)
D, DF, F, D, DF, F, x+y


-ACHTUNG:
D, DF, F, D, DF, F, a+b (during boxing stance)


-------------------------------------------------------------
-COMBOS:

(on the corner) y \\ F,x \\ F, D, DF, x \\ B, DB, D, DF, F, x \\ D, DF, F, DF, D, DB, B, x+y



y \\ F,x \\ F, D, DF, y \\ B, DB, D, DF, F, x \\ D, DF, F, y



D, D, a(or)b \\ a,a,a \\ x,x,x \\ D, DF, F, D, DF, F, x+y



B, DB, D, DF, F, a(or)b \\ y,y,y \\ D, DB, B a(or)b



b \\ F,x \\ F, D, DF, y \\ D, DF, F, D, DF, F, x+y



y \\ F, D, DF, x \\  D, DF, F, DF, D, DB, B, x+y



D, D, a(or)b \\ b,b,b \\ D, DF, F, D, DF, F, a+b



D, D, a(or)b \\ x,x,x(or)y,y,y \\ F, D, DF, b



D,DB,B, y \\ D, DF, F, D, DF, F, x+y



D, D, a(or)b \\ x,x,x \\ F, D, DF b



D,DB,B, y \\ D, DB, B a(or)b



D, y \\ D, DB, B a(or)b



b \\ F,x \\ F, D, DF b



and others...



-------------------------------------------------------

DISCLAIMER: 
This character is for WIN-M.U.G.E.N. use only. 
I will not be held responsable for any damage done to your Computer, your parents, your car...
...or your life. muahahaha!(...)

-------------------------------------------------------
INFO ABOUT THIS CHARACTER:
KUANDO is a totally original character maded pixel by pixel by AIDUZZI ;-)

CREDITS:
thanks to Elecbyte for making MUGEN
thanks to Antonio Navarra for hosting our character on his site (P.S. Antonio Navarra IS NOT AIDUZZI!!!)
thanks to Reu for giving me the honour to collaborate with him on the new version of EvilRyu!
thanks to Thundershock that is one of my best fan and contributor ;-)
thanks to all mugenizers that help me to love MUGEN!


Sorry for my bad english...
For contact and suggestions visit the site: www.thephotonfalls.com














