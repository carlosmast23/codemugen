Yashiro Nanakase(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<.DEF Overview>=====

Yashiro-KOF98.def -> Yashiro Nanakase
OrochiYashiro.def -> Orochi Yashiro


=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


*Yashiro Nanakase

-- Throw
Lever Blow - F or B, y

Hatchet Throw - F or B, b


-- Command Moves
Regret Bash - F, x

Step Side Kick - F, a


-- Super Moves
Missile Might Bash - B, DB, D, DF, F, x or y

Upper Duel - F, D, DF, x or y

Sledgehammer - D, DB, B, a or b

Jet Counter          - F, DF, D, DB, B, x or y
 ->Jet Counter Still - D, DF, F, x or y


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Million Bash Stream - D, DB, B, DB, D, DF, F, x or y

Final Impact - D, DF, F, D, DF, F, x or y


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Million Bash Stream - D, DB, B, DB, D, DF, F, x or y

Final Impact - D, DF, F, D, DF, F, x or y



*Orochi Yashiro

-- Throw
Baku - F or B, y

Beki - F or B, b


-- Command Moves
Saku - F, x

Bu - F, a


-- Super Moves
Musebu Daichi - F, DF, D, DB, B, F, x or y

Niragu Daichi - B, DB, D, DF, F, x or y

Odoru Daichi - B, DB, D, DF, F, a or b

Kujiku Daichi - D, DB, B, x or y


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Araburu Daichi - D, DF, F, D, DF, F, a or b

Hoeru Daichi - D, DF, F, D, DF, F, x or y

Ankoku Jigoku Gokuraku Otoshi - F, DF, D, DB, B, F, DF, D, DB, B, x or y


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Araburu Daichi - D, DF, F, D, DF, F, a or b

Hoeru Daichi - D, DF, F, D, DF, F, x or y

Ankoku Jigoku Gokuraku Otoshi - F, DF, D, DB, B, F, DF, D, DB, B, x or y


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
fxm508
JFCT555
Kong
Ohgaki


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
