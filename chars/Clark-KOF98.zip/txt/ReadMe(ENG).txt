Clark Still(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


-- Throw
Slamming German - F, y

Fisherman Buster - F, b

Death Lake Drive - F or B or U, Y or B


-- Command Moves
Stomping - F, a


-- Super Moves
Vulkan Punch - Tap x or y rapidly

Napalm Stretch(*) - F, D, DF, x or y

Super Arabian Burglary Back Breaker(*) - B, DB, D, DF, F, x

Rolling Cradle(*) - B, DB, D, DF, F, y

Franken Steiner(*) - F, D, DF, a or b

Super Argentina Back Breaker(*) - B, DB, D, DF, F, a or b

Flashing Elbow - D, DF, F, x or y while(*)


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Ultra Argentina Back Breaker - F, DF, D, DB, B, F, DF, D, DB, B, x or y

Running Three - B, DB, D, DF, F, B, DB, D, DF, F, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Ultra Argentina Back Breaker - F, DF, D, DB, B, F, DF, D, DB, B, x or y

Running Three - B, DB, D, DF, F, B, DB, D, DF, F, a or b


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
fxm508
JFCT555
Kong
Ohgaki
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
