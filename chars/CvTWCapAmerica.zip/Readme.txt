                       
                            _______________________________________________________
===========================| Captain America by Buckus |==========================
                            �������������������������������������������������������           

- Customized version of Captain America character from Capcom's Versus series
- Strong enough for Mugen 1.0, but made for Winmugen

=======================| Info |=======================

- This is my customized version of Captain America from Capcom's Versus series
- SPRITES ARE OPEN SOURCE!!! 
=======================| Button Key |=======================

U - up             x - weak punch         a - weak kick
D - down        y - medium punch      b - medium kick
F - forward     z - strong punch         c - strong kick
B - back         p - any punch             k - any kick
s - start          2p- two punches        2k- two kicks

=======================| System |=======================

Backward Dash:                B, B
Forward Dash:                   F, F
Run:                                   F, F (hold)
Dodge:                               F(or B) + a + x
Parry High:                         (tap) F
Parry Low:                         (tap) D
Air Parry:                           (tap) F (in Air)
Guard Breaker Attack:        b+y  (hold) [need at least 500 power]
Guard Counter:                     2p or 2k  (during standing or crouching guard)  [need at least 1500 power]
Fall Recovery:                     2p (while falling when hit)
Super Jump:                        D, U
Double Jump:                       U while jumping
Throw:				   x+y or a+b

*While charging a Guard Breaker Attack, you can cancel into a Dodge by holding B or F
*Dodging Backward makes you invunerable to throws but not projectiles
*Dodging Forward makes you invunerable to projectiles but not throws

=======================| Command Moves |=======================

Mid Kick:					b,b

=======================| Special Moves |=======================

Shield Slash:				QCF+p (air ok)
Charging Star :				QCF+k
Stars and Stripes:			F,QCF+p
Cartwheel:					HCB+p

=======================| Super Moves |=======================

-LVL 1 Supers
Hyper Stars and Stripes:	QCFx2+p 
Hyper Charging Star:		QCFx2+k

-LVL 2 Supers
Final Justice:			QCFx2+2p 

-MAX LVL Supers
Not available yet

=======================| Combo Notes |=======================

-Captain America can chain moves into each other. Here are his basic combo rules:

      1.  You can combo from weaker basic attacks into stronger ones

      2.  You can combo into special attacks from most basic attacks

      3.  You can combo into hyper attacks from all basic and special attacks

=======================| Guard Breaker |======================

-Can absord 1 normal or special attack/projectile (takes away 500 power)
-Vunerable to all throws and super attacks/projectiles
-If hit while charging, you'll take 1.5 times the damage of the opponent's attack
-If charging after absorded hit with 0 power, health will decrease instead

=======================| Special Thanks |=======================

Davismaximus- Helped a LOT with color separation.
P.o.t.S- Being Open Source [Too much to list]
Warusaki3/Vyn- Looked at some of their codes for examples
Just No Point/Kong- Sprites (Fx)
Me- Some sprite edits
Elecbyte- Creating MUGEN
...and anybody I missed (sure there's some)

=======================| History |=======================
5/15/13- Beta release
