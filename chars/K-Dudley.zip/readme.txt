Kame-Groove Dudley 3.34 by kamekaze
site: http://network.mugenguild.com/kamekaze/
---------------------

Changelog
-----------
bug fixes
hit velocities adjusted.
air blocking removed unless in k-style



  Controls
  --------
  c. = crouching
  N. = Neutral
  2p = two punches
  2k = two kicks
 --> = Follow up command
 
 Change modes
 -------------
 While selecting a super art press left or right
 
 Personal Action
 -------------------
 z+c            - Rose Taunt/Toss
 y+b            - Dash Cancel, Kaze Style only.
 While connecting with any move and you are grounded.
  
    Command Standing Attacks
    ----------------------
      F+x            - Mid blow
      F+y            - Gut Punch
      F+z            - Advancing Straight
      F+b            - Advancing body blow
      F+c            - Overhead Punch
      y+b            - Jumping Overhead, 3rd strike mode only.
      D,D,z          - Jumping Overhead, 2nd Impact mode only.

    Target Combos
    -----------------------
      x,y,b          - Target Combo 1 - special cancel-able in all but K-style
      F+x,y          - Target Combo 2, Not in second impact mode- special cancel-able
      a,b,y,z        - Target Combo 3
      c.a,b          - Target Combo 4 
      c.a,c.y,c.z    - Target Combo 5
      F+b,b,z        - Target Combo 6
      b,c,z          - Target Combo 7
      F+c,b          - Target Combo 8
      

    Throws
    ------
      Third Strike Mode and Kaze-Style
      -------------------------------
      F/B + a+x - Body Toss
      N.  + a+x - Gut Punches
      
      Second Impact Mode
      ------------------
      F/B + z - Body Toss
      F/B + y - Gut Punches
      
    Special Attacks
    ---------------
      B, D, F + x  - W. Machine Gun Blow
      B, D, F + y  - M. Machine Gun Blow
      B, D, F + z  - S. Machine Gun Blow
      B, D, F + 2p - EX Machine Gun Blow

      F, D, B + x  - W. Cross Counter
      F, D, B + y  - M. Cross Counter
      F, D, B + z  - S. Cross Counter
      F, D, B + 2p - EX Cross Counter


      F, D, DF + x  - W. Jet Upper
      F, D, DF + y  - M. Jet Upper
      F, D, DF + z  - S. Jet Upper
      F, D, DF + 2p - EX Jet Upper
      
      B, D, F + a  - W. Ducking
      B, D, F + b  - M. Ducking
      B, D, F + c  - S. Ducking
      B, D, F + 2k - EX Ducking
    --> x or y or z- Straight
    --> a or b or c- Upper

      Third Strike and Kaze-Style Only
      --------------------------------
      F, D, B + x  - W. Short Swing Blow
      F, D, B + y  - M. Short Swing Blow
      F, D, B + z  - S. Short Swing Blow
      F, D, B + 2p - EX Short Swing Blow
      
      Second Impact Mode Only
      --------------------------------
      D, DB, B + x  - W. New Wave Raucous
      D, DB, B + y  - M. New Wave Raucous
      D, DB, B + z  - S. New Wave Raucous
      D, DB, B + 2p - EX New Wave Raucous
      
    Hyper Attacks (each uses 1 power bar)
    -------------
    Select one at the beggining of the match.

    Hyper Attacks: Kaze Style (each uses 1 power bar)
    -------------
     D,DF,F,D,DF,F, p- Rocket Uppercut
     D,DB,B,D,DB,B, p- Corkscrew Blow
     D,DF,F,D,DF,F  p- Rolling Thunder
     
     Ultra Attack(when combo meter is full):
     -------------
     D,DF,F,D,DF,F, 2p - Rolling Thunderbolt
     
  Combo notes
  -----------

      1.  Target combo 2 can chain into specials or hypers otherwise
          they do not chain.
          
      2.  Target Combo 4 can chain into Hypers in Second Impact mode

      3.  The Combo meter builds based on your combos, when it
          is maxed out you can perform a Ultra Attack.
          
      4.  Dash Canceling requires 1 stock of power.
      
 More Notes
---------------
1. If it is too difficult for you to parry, you can change the settings
in the config.txt

2. When you select a color press start again to close it.
          
Special thanks
--------------
Elecbyte - For the awesome that is .sff2
MooMaster666- Betatesting,win portrait
MC2- Betatesting, palettes
Blackinu - Betatesting, palettes
Kirishima-Betatesting, palettes
Vans- Betatesting
Shwa- Betatesting
Dishampow - Beta testing, palettes
Anthemhero - beta testing
Cyanide - beta testing
insanius - hitsounds
Anyone else I forgot
Capcom - why not, they dudley mang.
