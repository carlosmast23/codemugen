Robert Garcia(KOF'98 Style) by Ikaruga
for WinMugen / Mugen 1.0

*Open Source

=====<.DEF Overview>=====

Robert-KOF98.def -> Normal Version
RobertEX.def -> KOF'99 Costume Version


=====<Movelist>=====

-- Button Assign
x - Light Punch
y - Hard Punch
z - Knockdown Attack
a - Light Kick
b - Hard Kick
c - Maximum Mode(ADV)/Power Charge(EX)
start - Taunt


-- Moves
Run(ADV)/Front Step(EX) - F, F
Back Step - B, B
Knockdown Attack - y+b or z
GC Knockdown Attack - y+b or z while guarding
Roll(ADV)/Evade(EX) - x+a
GC Roll - x+a while guarding(Requires 1 Power Bar)
Maximum Mode(ADV) - x+a+y(Requires 1 Power Bar)
Power Charge(EX) - x+a+y
Safe Fall Recovery - x+a when nearing ground while falling


*Normal Mode

-- Throw
Ryutyo Kyaku - F, y

Kubikiri Nage - F, b


-- Command Moves
Kouryu Koukyaku Geri - F, x

Ryuhon Shu - F, a


-- Super Moves
Ryugeki Ken - D, DF, F, x or y

Ryuga - F, D, DF, x or y

Hien Senpu Kyaku - F, DF, D, DB, B, a or b

Hien Ryujin Kyaku - (In Air)D, DB, B, a or b

Kyokugenryu Renbu Kyaku - (close)B, DB, D, DF, F, a or b

Ryuzan Sho - F, D, DF, a or b


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Haoh Shoukou Ken - F, B, DB, D, DF, F, x or y

Ryuko Ranbu - D, DF, F, DF, D, DB, B, x or y

Muei Sippu Jyudan Kyaku - D, DF, F, D, DF, F, a or b


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Haoh Shoukou Ken - F, B, DB, D, DF, F, x or y

Ryuko Ranbu - D, DF, F, DF, D, DB, B, x or y

Muei Sippu Jyudan Kyaku - D, DF, F, D, DF, F, a or b


*Art of Fighting Mode(select to start + any key)

-- Throw
Ryutyo Kyaku - F, y

Kubikiri Nage - F, b


-- Command Moves
Kouryu Koukyaku Geri - F, x

Ryuhon Shu - F, a


-- Super Moves
Ryugeki Ken - D, DF, F, x or y

Ryuga - F, D, DF, x or y

Hien Shippu Kyaku - F, DF, D, DB, B, a or b

Hien Ryujin Kyaku - (In Air)D, DB, B, a or b

Gen'ei Kyaku - F, B, F, a or b


-- DM(ADV: Requires 1 Power Bars / EX: MAX Mode or In low life)
Haoh Shoukou Ken - F, B, DB, D, DF, F, x or y

Ryuko Ranbu - D, DF, F, DF, D, DB, B, x or y


-- SDM(ADV: In MAX Mode & Requires 1 Power Bars / EX: In MAX Mode & In low life)
Haoh Shoukou Ken - F, B, DB, D, DF, F, x or y

Ryuko Ranbu - D, DF, F, DF, D, DB, B, x or y


=====<Credits>=====

SNK PLAYMORE
elecbyte

Ahuron
Cirio
fxm508
JFCT555
Kong
Ohgaki
Vans
Wuwo


=====<Contact>=====

EMail : ikaruga.m134@gmail.com
