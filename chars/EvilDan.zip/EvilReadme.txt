
(HEY, IF YOU ARE USING DOSMUGEN, THIS IS THE WRONG VERSION! RUN TO THE SITE AND DOWNLAD THE RIGHT ONE!)

Hi, I'm ilcane87 (ilcane87@yahoo.it) and i'm italian! This is a beta of my character EvilDan, so if you find any bugs, please tell me and I'll fix 'em!

This is my second char, I hope you have fun with him!

You will find my first char DanHibiki and newer versions of EvilDan here: http://www.pandemonium.altervista.org/

Be sure to download also the suggested stage (by CAMRAT, it's a stage that never ends!) and music for EvilDan, as well as the DanHibiki music! :D
(The stage, for now, doesn't work on WinMugen)

=====================================================
FAQ:

-Are there any differences between the Dos version and the Windows version?
-The two versions are exactly the same. The only difference is that in WinMugen the AI's activation is slower because of some system changes.

-His AI isn't very competitive!
-Remember that this isn't a complete char, I'll make it stronger as I upgrade the char! But I don't want it to be stronger than EvilKen\EvilRyu's one.

-There are not many moves!
-They are coming, it's still not a complete char now.

-He is too serious to be Dan!!
-There will be a lot of joking dan-style moves!

-I don't want a joking Evil!!
-Don't worry, he'll have a lot of powerfull moves too!!

=====================================================
NEWS:
-New Special Move added: Premium Sign!
-Many and many bug fixes and corrections everywhere
-Improvement to AI
-Corrected all bugs in WinMugen
-Added a new Super Move: Shin Premium Sign!! :D
-Added strong and weak variations of the new super.
-Changed some Hit Sparks
-Added a new lovely win-pose.
-Written the words you are reading now! :P

WHAT'S FEATURED:
-3D flame surges, sparks, speckles and splash effects from EvilKen/EvilRyu...!
-The not really first Special Meta Super Special Moves system!
-The very first Special Meta Weak Special Moves system!
-All Dan based moves
-Tonnes of original super and special moves!(and more will come...)
-Never seen before edits of Dan, thanks also to ShinHi(REALLY!!)!
-Ability to do OTG combos.
-Ability to chain normal attacks!
-Ability to chain normal attacks into special moves!
-Ability to cancel special moves into super moves!
-Ability to Super Cancel super moves into supermoves!
-Combo Rating system!
-Capcom vs SNK charge up!
-Capcom vs SNK style superjump!
-Capcom vs SNK flame sound, landing sound, hit sounds, block sounds, voice samples!
-Holy crap! Tonnes of comboability! 

WHAT'S TO BE DONE:
-Intro and Ending in Arcade Mode
-Special Intros against specific characters.
-Fix the sound issues in WinMugen
-Many cool palettes
-Many intros and win-poses
-Fix the Hurricane-intro bugs on some stages
-Fix everything that needs to be fixed
-Tonnes of original super and special moves!
-Better Standing-Pose
-TAUNTS!
-...
-ShunGokou Satsu (redo raging demon)!!
-EvilBlanka!!! (CAN SOMEONE HELP ME WITH THE SPRITES?!) :D
-Custom Combo Mode
-Everything a mere human can imagine!!!!!!!

===========================================
// Installation //
===========================================

This version of Evil Dan requires version 2004.07.04 or newer of the WinMugen engine.
If your engine is up to date, simply create asubdirectory <mugendir>\chars\evildan,
(where <mugendir> represents the directory where MUGEN is installed) and move the
character files into that directory.

If you want Evil Dan to appear on the character select screen, edit
data\select.cfg and add "evildan" to the list of characters.

====================================================
<<<EXPLAINATION OF META SUPER SPECIAL MOVES>>>
===================================================
MSSMs can be performed by combining three level one super moves together. Simply put, they happen on your second super cancel. MSSMs also happen with a probablity of 10% whenever you do a super special move. Only Level one Super Special Moves have MSSM versions.

====================================================
<<<EXPLAINATION OF META WEAK SPECIAL MOVES>>>
===================================================
MWSMs happen with a probablity of 10% whenever you do a super special move. Only Level one Super Special Moves have MWSM versions.

====================================================
MOVES LIST:

------------------------------------>
Extra Moves:

Air recover: 2 punches or 2 kicks while falling

Ground recover: 2 punches or 2 kicks while near ground.

Ground roll reover: 2 punches or 2 kicks while lying on ground

Taunt: Start button *(Increases defense)*

MiniTaunt: d, d, Start button (randomly performs one of three mini taunts!)

Normal Jump launch: Jump after Crouching Forward  heavy punch

Super Jump Lanuch: Jump after Crouching heavy punch

----------------------------------->

Alpha counters: Alpha counters are performed when the player does a back to down motion, followed by an attack button. Alpha counters require at least ONE level.

Punch counter: Dan does a flaming shoryuken which sends his opponent flying

Kick counter: Dan performs a DakkuKiaku

Air Kick counter: Dan does a DakkuKiaku

Air Punch counter: Dan does a TenmaKujinKiaku

----------------------------------->
Special moves:

Seoi Nage: forward/backward + 2punches
If nearby opponent, Dan will grab him and throw him away.

Saikyou Jigoku Otoshi: forward/backward + 2kicks (kkk rapidly)
Dan will grap his opponent and do a series of quick punches on his opponent's head followed by a quick slap which sends the opponent far away.

Seoi Nage: forward/backward + 2punches in air
If nearby opponent, Dan will grab him and throw him away.

Saikyou Jigoku Otosareta: forward/backward + 2kicks in air
If nearby opponent, Dan will grab him and pull him to the earth causing his opponent an hard headache!

Gadouken: qcf + punch
Dan gathers his internal energy and fires a ball of purple energy which flies across the screen.
LP does travels slowly and does one hit, MP travels faster and does two, HP goes even faster and does three.
Heavier versions will "eat" other forms of projectiles.

Premium Sign: qcf + kick
Dan picks up a portrait and signs it. Then he throws it to the opponent.
But, what happens? The portrait keeps flying, and it keeps following Dan's opponent!
That's because there is a ghost inside, and, as it hits the opponent, it will come out and hit him with a SpecialMove that changes depending from the strength of the kick you pressed!
It's a usefull tactic to let the portrait go towards the opponent, so it will come back and hit him from behind!
You can also make the ghost come out while flying by pressing  LK+MK+HK

Dakku Kiaku: qcb + kick (can be done in air)
Dan charges his opponent with kicks. The number of kicks depends to the strength of the button.
Perfect for air combos.

Kouryuken : dp + punch
Dan brings his fist up and flys upwards into the air.
Dan's basic anti air attack.

Seoi Kouryuken: dp + punch (During or after dragon punch)
Dan brings his other fist up into the air for a second dragon punch.
Dan's basic follow up for the dragon punch.

Danujin Kyaku: qcf + kick
Dan will dive kick downward. Lk goes straight through, mk makes dan rebound after contact and hk allows dan to slip in a quick attack after a flaming dive.

Makuu Shihai : dp + 2 punches/kicks or rdp + 2 punches/kicks
Dan moves behind a parallel framespan.
DP makes dan warp forward, RDP makes dann warp backward. Punches makes him travel further than kicks.
A very useful move for crossups...

Zenpu Tenshin: LP+LK
Dan rolls like a wild tire.
Can go through any attack.

Shinpou Dan: Medium Punch + Medium Kick
A ghost of Dan comes suddenly to help his master and charges his energy.

------------------------------------->
Super Moves:

One Bar Super combos:

Shin DakkuKiaku: qcf, qcf + kick (can be done in air) *MSSM Possible* *MWSM Possible*
Dan charges the opponent with a kicking rage.

Shinkuu Gadouken: qcf, qcf + punch *MSSM Possible* *MWSM Possible*
Dan gathers his internal energy and compresses it, thrusting it out for a great 9 hits.
The MSSM Shinkuu Gadouken will leave a twirl of energy in the opponent's body.
Dan can unleash this energy pressing LP+MP+HP (unblockable!)

Shin Premium Sign: hcf + 2kicks *MSSM Possible* *MWSM Possible*
Dan picks up a void portrait and signs it. Then he jumps inside it and he starts flying! 
You can move the flying Portrait anywhere by pressing UP,DOWN,LEFT,RIGHT!
When the portrait hits the opponent, Dan comes out with 5 other ghosts and they start hitting the opponent.
There are rumours that the most powerfull of ghosts will come out in the Weak Variation of this Super Move... :D

Gadanu Messhuu: qcf, qcf + kick (In Air) *MSSM Possible* *MWSM Possible*
Dan sends three ghosts of energy to the opponent, following 'em with a flaming kick!

KouryuRekka: qcf, qcf + kick *MSSM Possible* *MWSM Possible*
Dan does a small advancing dragon punch, then does a final dragon punch which sends the opponent flying!
Easy to combo into and out off.


Two bar super combos:

Hisshou Buraiken: qcb,qcb+punch
Dan teleports behind the opponent and charges him with an electric energy that he can control!
Then he throws away his enemy to throw a projectile storm to him. 
As the opponent is unable to move, two ghosts start recharging Dan, who is focusing for the next attack.
When ready, Dan delivers a super DragonPunch that sends the opponent flying.

Three bar super combos:
Coming soon!

Special Modes:
Coming sooner!

--------------------------->
Tips and Tricks:

Taunt! Dan's defense increases after his taunt so slip one in every round to keep the upper hand.

When you throw a portrait, it's a usefull tactic to let it go towards the opponent, so it will come back and hit him from behind!

Dan's hadouken is mainly used to get closer to the opponent. Try throwing a slow hadouken then ashura warping forward to get behind the opponent.

Super cancel! You never know when your next chance to combo the opponent into a super combo will be, so when you do hit succesfully, try to burn all your levels.

Stay out of corners! Corners are any player's worse enemy. Use Dan's Hadouken/Ashura warp crossup to get you out.

Don't stay defensive! Use Dan's alpha counter's turn the tables! Back to down motion and attack will use up one level of your super bar. Counter with punch does an invulnerable dragon punch, counter with kick does a strong dakkukiaku.

Recover! Do not let yourself be juggled mercilessly by your foes, make use of the air/ground recovers whenever possible.

Want to learn new combos? Watch the AI in action! Make use of EvilDan's air throws to perform loooong combos! (as for EvilKen)

------------------------>

Credits/Special Thanx:

God, for everything!

Elecbyte, for MUGEN, Yeah!!

Capcom, for the COOL games, and for Dan of course!!

ShinHi, for allowing me to use his sprites(the original idea of the char was his)! If there is someone I hope he likes this char, it's you!!

Dan_hibiki00, bacuse he loves Dan too, and for his great coming Rpgs and Chars, and for his support, and fo we'll maybe make a Dan Rpg together, and for.... Anything else? :P

R, for making the first Dan I updated!!

Reu, for allowing me to use things from his chars, that are the best ever made!!!!!!! Download 'em in: http://mi.mgbr.net THANX REU!!

GCNMario, for a complex code and for his wonderfull and ultra-accurate chars!

Pandemonium, for making a site for us, for his continous support, AND FOR THE FIRST EVIL-BLANKA EVER MADE (will be added soon!)! :D

Zcharcad, for it's the best character editor!

ShinAkuma2004, for all his Kick@$$ ideas!!!!

Cain Highwind, for all the CvsS sounds, as for his suggestions.

Sethzakuen for the pink AfterImage code.

VK and Tenebrous, for making those AI tutorials I used (your M.Bison is great!!).

Faye, for having been my first host, check his Cute site: http://cutemugen.free.fr/

Beppo, for having made the coolest (italian) site of all: http://run.to/Bepposoft

The StreetFighter comix, for being so cool

NINTENDO, cause it'll always be the best videogames hardware/software house!!!!!!!! :) 

Guys that thanked me, because they thanked me!

Guys I forgot, and they are a lot! :D


Made in Italy, Modena!

Come Visit me and Pandemonium at DanMugen!
*DanMugen -=> http://www.pandemonium.altervista.org/

Coding is fun! If ilcane87 can code, so can you!






